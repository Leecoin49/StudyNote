CREATE VIEW dbo.View_InvestmentProjects
AS
SELECT  dbo.CT_Credit_text.id, dbo.CT_CreditSource.grabdatacode, dbo.CT_Credit_text.sourceid, 
                   dbo.CT_CreditSource.datasource, dbo.CT_CreditSource.sitename, dbo.CT_CreditSource.sitesort, 
                   dbo.CT_CreditSource.submodule, dbo.CT_Credit_text.url, dbo.CT_Credit_field.title, dbo.CT_Credit_field.declaredate, 
                   dbo.CT_Credit_text.filepath, dbo.CT_Credit_text.relativepath, dbo.CT_Credit_text.listpath, dbo.CT_Credit_field.inserturl, 
                   dbo.CT_Credit_field.thead, dbo.CT_Credit_text.tablehead, dbo.CT_Credit_text.isfile, dbo.CT_Credit_text.isimg, 
                   dbo.CT_Credit_text.guid, dbo.CT_Credit_text.uniqueguid, dbo.CT_Credit_text.state, dbo.CT_Credit_text.Entrydate, 
                   dbo.CT_Credit_text.Entrytime, dbo.CT_Credit_text.TMStamp, dbo.CT_Credit_text.macip, 
                   dbo.CT_CreditSource.empty_content, dbo.CT_Credit_field.party, dbo.CT_Credit_text.newrelativepath, 
                   dbo.CT_Credit_text.newfilepath, dbo.CT_CreditSource.rawurl, dbo.CT_Credit_text.parentGuid, 
                   dbo.CT_Credit_text.listrelativepath
FROM      dbo.CT_Credit_text INNER JOIN
                   dbo.CT_CreditSource ON dbo.CT_Credit_text.sourceid = dbo.CT_CreditSource.guid INNER JOIN
                   dbo.CT_Credit_field ON dbo.CT_Credit_text.guid = dbo.CT_Credit_field.guid
WHERE   (dbo.CT_CreditSource.modulecode = 305) AND (dbo.CT_CreditSource.submodule IN ('投资项目', '投资平台', '部委审批', 
                   '重大项目名单', '环评备案', '建筑市场监管', '招投标信息', '征收土地信息', '工程平台'))
go

exec sp_addextendedproperty 'MS_DiagramPane1', N'[0E232FF0-B466-11cf-A24F-00AA00A3EFFF, 1.00]
Begin DesignProperties = 
   Begin PaneConfigurations = 
      Begin PaneConfiguration = 0
         NumPanes = 4
         Configuration = "(H (1[21] 4[76] 2[3] 3) )"
      End
      Begin PaneConfiguration = 1
         NumPanes = 3
         Configuration = "(H (1 [50] 4 [25] 3))"
      End
      Begin PaneConfiguration = 2
         NumPanes = 3
         Configuration = "(H (1 [50] 2 [25] 3))"
      End
      Begin PaneConfiguration = 3
         NumPanes = 3
         Configuration = "(H (4 [30] 2 [40] 3))"
      End
      Begin PaneConfiguration = 4
         NumPanes = 2
         Configuration = "(H (1 [56] 3))"
      End
      Begin PaneConfiguration = 5
         NumPanes = 2
         Configuration = "(H (2 [66] 3))"
      End
      Begin PaneConfiguration = 6
         NumPanes = 2
         Configuration = "(H (4 [50] 3))"
      End
      Begin PaneConfiguration = 7
         NumPanes = 1
         Configuration = "(V (3))"
      End
      Begin PaneConfiguration = 8
         NumPanes = 3
         Configuration = "(H (1[56] 4[18] 2) )"
      End
      Begin PaneConfiguration = 9
         NumPanes = 2
         Configuration = "(H (1 [75] 4))"
      End
      Begin PaneConfiguration = 10
         NumPanes = 2
         Configuration = "(H (1[66] 2) )"
      End
      Begin PaneConfiguration = 11
         NumPanes = 2
         Configuration = "(H (4 [60] 2))"
      End
      Begin PaneConfiguration = 12
         NumPanes = 1
         Configuration = "(H (1) )"
      End
      Begin PaneConfiguration = 13
         NumPanes = 1
         Configuration = "(V (4))"
      End
      Begin PaneConfiguration = 14
         NumPanes = 1
         Configuration = "(V (2))"
      End
      ActivePaneConfig = 0
   End
   Begin DiagramPane = 
      Begin Origin = 
         Top = 0
         Left = 0
      End
      Begin Tables = 
         Begin Table = "CT_Credit_text"
            Begin Extent = 
               Top = 0
               Left = 104
               Bottom = 920
               Right = 648
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "CT_CreditSource"
            Begin Extent = 
               Top = 420
               Left = 795
               Bottom = 1081
               Right = 1398
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "CT_Credit_field"
            Begin Extent = 
               Top = 96
               Left = 2002
               Bottom = 1022
               Right = 2560
            End
            DisplayFlags = 280
            TopColumn = 0
         End
      End
   End
   Begin SQLPane = 
   End
   Begin DataPane = 
      Begin ParameterDefaults = ""
      End
   End
   Begin CriteriaPane = 
      Begin ColumnWidths = 11
         Column = 3288
         Alias = 900
         Table = 2520
         Output = 720
         Append = 1400
         NewValue = 1170
         SortType = 1356
         SortOrder = 1416
         GroupBy = 1350
         Filter = 10800
         Or = 1350
         Or = 1350
         Or = 1943
      End
   End
End
', 'SCHEMA', 'dbo', 'VIEW', 'View_InvestmentProjects'
go

exec sp_addextendedproperty 'MS_DiagramPaneCount', 1, 'SCHEMA', 'dbo', 'VIEW', 'View_InvestmentProjects'
go

