





--============================================        
-- tbstru EnvJsonMatch      
-- is_proc_input_tb EnvJsonMatch,2        
-- DATE:2023/5/10
--============================================        
CREATE PROCEDURE [dbo].[DB_AUTO_EnvJsonMatch_U]                          
(    @ID1 INT, --流水号      
     @SiteName	varchar(200)	,
	@SiteSort	varchar(100)	,
	@title	varchar(200)	,
	@TableName	varchar(200)	,
	@KeyWord_CN	varchar(200)	,
	@KeyWord_JS	varchar(200)	,
	@Parent_JS	varchar(200)	,
	@FiledValue	varchar(200)	,
	@Html_Type	varchar(20),--int	,
	@MDataSourceCode	varchar(200)	,
	@Group	varchar(200)	,
	@isModel	varchar(20),--int	,
	@JSONValue	varchar(5000)	,
	@MatchValue	varchar(5000)	,
	@EnvJsonMatch1	varchar(500)	,
	@EnvJsonMatch2	varchar(500)	,
	@Flag	varchar(20),--int	,
   @LoginName  varchar(50)                        
) AS                       
   
 IF NOT EXISTS(SELECT 1 FROM EnvJsonMatch WHERE ID=@ID1)
 BEGIN      
    RAISERROR ('ID不存在数据表中,请核查', 16, 1)      
	RETURN @@ERROR        
 END     
 

--数据储存开始        
SET XACT_ABORT ON          
BEGIN TRAN FLAG     

	DECLARE @SQL VARCHAR(8000)
	SET @SQL='
	update EnvJsonMatch         
	Set ' 
	IF @SiteName!='-1' SET @SQL= @SQL+'SiteName='''+@SiteName +''','+CHAR(10)
	IF @SiteSort!='-1' SET @SQL= @SQL+'SiteSort='''+@SiteSort +''','+CHAR(10)
	IF @Title!='-1' SET @SQL= @SQL+'Title='''+@Title +''','+CHAR(10)
	IF @TableName!='-1' SET @SQL= @SQL+'TableName='''+@TableName +''','+CHAR(10)
	IF @KeyWord_CN!='-1' SET @SQL= @SQL+'KeyWord_CN='''+@KeyWord_CN +''','+CHAR(10)
	IF @KeyWord_JS!='-1' SET @SQL= @SQL+'KeyWord_JS='''+@KeyWord_JS +''','+CHAR(10)
	IF @Parent_JS!='-1' SET @SQL= @SQL+'Parent_JS='''+@Parent_JS +''','+CHAR(10)
	IF @FiledValue!='-1' SET @SQL= @SQL+'FiledValue='''+@FiledValue +''','+CHAR(10)
	IF @Html_Type!='-1' SET @SQL= @SQL+'Html_Type='''+@Html_Type +''','+CHAR(10)
	IF @MDataSourceCode!='-1' SET @SQL= @SQL+'MDataSourceCode='''+@MDataSourceCode +''','+CHAR(10)
	IF @Group!='-1' SET @SQL= @SQL+'[Group]='''+@Group +''','+CHAR(10)
	IF @isModel!='-1' SET @SQL= @SQL+'isModel='''+@isModel +''','+CHAR(10)
	IF @JSONValue!='-1' SET @SQL= @SQL+'JSONValue='''+@JSONValue +''','+CHAR(10)
	IF @MatchValue!='-1' SET @SQL= @SQL+'MatchValue='''+@MatchValue +''','+CHAR(10)
	IF @EnvJsonMatch1!='-1' SET @SQL= @SQL+'EnvJsonMatch1='''+@EnvJsonMatch1 +''','+CHAR(10)
	IF @EnvJsonMatch2!='-1' SET @SQL= @SQL+'EnvJsonMatch2='''+@EnvJsonMatch2 +''','+CHAR(10)
	IF @Flag!='-1' SET @SQL= @SQL+'Flag='''+@Flag +''','+CHAR(10)
	IF isnull(@SiteName,'')='' SET @SQL= @SQL+'SiteName= NULL,'+CHAR(10)
	IF isnull(@SiteSort,'')='' SET @SQL= @SQL+'SiteSort= NULL,'+CHAR(10)
	IF isnull(@Title,'')='' SET @SQL= @SQL+'Title= NULL,'+CHAR(10)
	IF isnull(@TableName,'')='' SET @SQL= @SQL+'TableName= NULL,'+CHAR(10)
	IF isnull(@KeyWord_CN,'')='' SET @SQL= @SQL+'KeyWord_CN= NULL,'+CHAR(10)
	IF isnull(@KeyWord_JS,'')='' SET @SQL= @SQL+'KeyWord_JS= NULL,'+CHAR(10)
	IF isnull(@Parent_JS,'')='' SET @SQL= @SQL+'Parent_JS= NULL,'+CHAR(10)
	IF isnull(@FiledValue,'')='' SET @SQL= @SQL+'FiledValue= NULL,'+CHAR(10)
	IF isnull(@Html_Type,'')='' SET @SQL= @SQL+'Html_Type= NULL,'+CHAR(10)
	IF isnull(@MDataSourceCode,'')='' SET @SQL= @SQL+'MDataSourceCode= NULL,'+CHAR(10)
	IF isnull(@Group,'')='' SET @SQL= @SQL+'[Group]= NULL,'+CHAR(10)
	IF isnull(@isModel,'')='' SET @SQL= @SQL+'isModel= NULL,'+CHAR(10)
	IF isnull(@JSONValue,'')='' SET @SQL= @SQL+'JSONValue= NULL,'+CHAR(10)
	IF isnull(@MatchValue,'')='' SET @SQL= @SQL+'MatchValue= NULL,'+CHAR(10)
	IF isnull(@EnvJsonMatch1,'')='' SET @SQL= @SQL+'EnvJsonMatch1= NULL,'+CHAR(10)
	IF isnull(@EnvJsonMatch2,'')='' SET @SQL= @SQL+'EnvJsonMatch2= NULL,'+CHAR(10)
	
	SET @SQL=@SQL+'
	EntryDate=CONVERT(varchar(10),getdate(),120),
	EntryTime=CONVERT(varchar(10),getdate(),108) 
    where id='+Cast(@ID1 as varchar)+' '
	--PRINT(@SQL)
	EXEC(@SQL)
	
 COMMIT TRAN FLAG     
 RETURN @@ERROR    
 








go

