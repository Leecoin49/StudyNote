/* dbo.View_InvestmentProjects_File source*/
CREATE VIEW dbo.View_InvestmentProjects_File
AS
SELECT  dbo.CT_Credit_file.id, dbo.CT_CreditSource.grabdatacode, dbo.CT_CreditSource.sitename, dbo.CT_CreditSource.sitesort, 
                   dbo.CT_CreditSource.datasource, dbo.CT_CreditSource.submodule, dbo.CT_Credit_text.sourceid, dbo.CT_Credit_file.url, 
                   dbo.CT_Credit_file.pathdate, dbo.CT_Credit_field.declaredate, dbo.CT_Credit_file.guid, dbo.CT_Credit_file.parentguid, 
                   dbo.CT_Credit_file.filepath, dbo.CT_Credit_file.relativepath, dbo.CT_Credit_file.state, dbo.CT_Credit_file.macip, 
                   dbo.CT_Credit_file.Entrytime, dbo.CT_Credit_file.Entrydate, dbo.CT_Credit_file.TMStamp, dbo.CT_Credit_file.filename, 
                   dbo.CT_Credit_file.run_num, dbo.CT_CreditSource.polling_num, dbo.CT_Credit_file.unzip_status
FROM      dbo.CT_Credit_file INNER JOIN
                   dbo.CT_Credit_text ON dbo.CT_Credit_file.parentguid = dbo.CT_Credit_text.guid INNER JOIN
                   dbo.CT_CreditSource ON dbo.CT_Credit_text.sourceid = dbo.CT_CreditSource.guid INNER JOIN
                   dbo.CT_Credit_field ON dbo.CT_Credit_text.guid = dbo.CT_Credit_field.guid
WHERE   (dbo.CT_Credit_file.modulecode = 305) AND (dbo.CT_CreditSource.submodule IN ('投资项目', '投资平台', '部委审批', 
                   '重大项目名单', '环评备案', '建筑市场监管', '工程平台'))
go

exec sp_addextendedproperty 'MS_DiagramPane1', N'[0E232FF0-B466-11cf-A24F-00AA00A3EFFF, 1.00]
Begin DesignProperties = 
   Begin PaneConfigurations = 
      Begin PaneConfiguration = 0
         NumPanes = 4
         Configuration = "(H (1[56] 4[39] 2[3] 3) )"
      End
      Begin PaneConfiguration = 1
         NumPanes = 3
         Configuration = "(H (1 [50] 4 [25] 3))"
      End
      Begin PaneConfiguration = 2
         NumPanes = 3
         Configuration = "(H (1 [50] 2 [25] 3))"
      End
      Begin PaneConfiguration = 3
         NumPanes = 3
         Configuration = "(H (4 [30] 2 [40] 3))"
      End
      Begin PaneConfiguration = 4
         NumPanes = 2
         Configuration = "(H (1 [56] 3))"
      End
      Begin PaneConfiguration = 5
         NumPanes = 2
         Configuration = "(H (2 [66] 3))"
      End
      Begin PaneConfiguration = 6
         NumPanes = 2
         Configuration = "(H (4 [50] 3))"
      End
      Begin PaneConfiguration = 7
         NumPanes = 1
         Configuration = "(V (3))"
      End
      Begin PaneConfiguration = 8
         NumPanes = 3
         Configuration = "(H (1[56] 4[18] 2) )"
      End
      Begin PaneConfiguration = 9
         NumPanes = 2
         Configuration = "(H (1 [75] 4))"
      End
      Begin PaneConfiguration = 10
         NumPanes = 2
         Configuration = "(H (1[66] 2) )"
      End
      Begin PaneConfiguration = 11
         NumPanes = 2
         Configuration = "(H (4 [60] 2))"
      End
      Begin PaneConfiguration = 12
         NumPanes = 1
         Configuration = "(H (1) )"
      End
      Begin PaneConfiguration = 13
         NumPanes = 1
         Configuration = "(V (4))"
      End
      Begin PaneConfiguration = 14
         NumPanes = 1
         Configuration = "(V (2))"
      End
      ActivePaneConfig = 0
   End
   Begin DiagramPane = 
      Begin Origin = 
         Top = 0
         Left = 0
      End
      Begin Tables = 
         Begin Table = "CT_Credit_file"
            Begin Extent = 
               Top = 3
               Left = 175
               Bottom = 607
               Right = 434
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "CT_Credit_text"
            Begin Extent = 
               Top = 14
               Left = 526
               Bottom = 331
               Right = 826
            End
            DisplayFlags = 280
            TopColumn = 4
         End
         Begin Table = "CT_CreditSource"
            Begin Extent = 
               Top = 2
               Left = 1379
               Bottom = 761
               Right = 1754
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "CT_Credit_field"
            Begin Extent = 
               Top = 28
               Left = 1059
               Bottom = 191
               Right = 1241
            End
            DisplayFlags = 280
            TopColumn = 0
         End
      End
   End
   Begin SQLPane = 
   End
   Begin DataPane = 
      Begin ParameterDefaults = ""
      End
   End
   Begin CriteriaPane = 
      Begin ColumnWidths = 11
         Column = 3780
         Alias = 900
         Table = 1176
         Output = 720
         Append = 1400
         NewValue = 1170
         SortType = 1356
         SortOrder = 1416
         GroupBy = 1350
         Filter = 6324
         Or = 1350
         Or = 1350
         Or = 1350
      End
   End
End
', 'SCHEMA', 'dbo', 'VIEW', 'View_InvestmentProjects_File'
go

exec sp_addextendedproperty 'MS_DiagramPaneCount', 1, 'SCHEMA', 'dbo', 'VIEW', 'View_InvestmentProjects_File'
go

