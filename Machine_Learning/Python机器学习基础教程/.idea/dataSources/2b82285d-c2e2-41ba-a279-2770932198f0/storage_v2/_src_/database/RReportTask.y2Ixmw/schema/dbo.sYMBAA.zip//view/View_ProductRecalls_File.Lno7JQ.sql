CREATE VIEW dbo.View_ProductRecalls_File
AS
SELECT  dbo.CT_Credit_file.id, dbo.CT_CreditSource.sitename, dbo.CT_CreditSource.sitesort, dbo.CT_CreditSource.grabdatacode, 
                   dbo.CT_Credit_file.url, dbo.CT_Credit_file.filename, dbo.CT_Credit_file.guid, dbo.CT_Credit_file.parentguid, 
                   dbo.CT_Credit_file.filepath, dbo.CT_Credit_file.relativepath, dbo.CT_Credit_file.state, dbo.CT_Credit_file.Entrydate, 
                   dbo.CT_Credit_file.Entrytime, dbo.CT_Credit_file.TMStamp
FROM      dbo.CT_CreditSource INNER JOIN
                   dbo.CT_Credit_text ON dbo.CT_CreditSource.guid = dbo.CT_Credit_text.sourceid INNER JOIN
                   dbo.CT_Credit_file ON dbo.CT_Credit_text.guid = dbo.CT_Credit_file.parentguid
WHERE   (dbo.CT_CreditSource.modulecode = '399') AND (dbo.CT_CreditSource.submodule = '产品召回')
go

exec sp_addextendedproperty 'MS_DiagramPane1', N'[0E232FF0-B466-11cf-A24F-00AA00A3EFFF, 1.00]
Begin DesignProperties = 
   Begin PaneConfigurations = 
      Begin PaneConfiguration = 0
         NumPanes = 4
         Configuration = "(H (1[39] 4[55] 2[3] 3) )"
      End
      Begin PaneConfiguration = 1
         NumPanes = 3
         Configuration = "(H (1 [50] 4 [25] 3))"
      End
      Begin PaneConfiguration = 2
         NumPanes = 3
         Configuration = "(H (1 [50] 2 [25] 3))"
      End
      Begin PaneConfiguration = 3
         NumPanes = 3
         Configuration = "(H (4 [30] 2 [40] 3))"
      End
      Begin PaneConfiguration = 4
         NumPanes = 2
         Configuration = "(H (1 [56] 3))"
      End
      Begin PaneConfiguration = 5
         NumPanes = 2
         Configuration = "(H (2 [66] 3))"
      End
      Begin PaneConfiguration = 6
         NumPanes = 2
         Configuration = "(H (4 [50] 3))"
      End
      Begin PaneConfiguration = 7
         NumPanes = 1
         Configuration = "(V (3))"
      End
      Begin PaneConfiguration = 8
         NumPanes = 3
         Configuration = "(H (1[56] 4[18] 2) )"
      End
      Begin PaneConfiguration = 9
         NumPanes = 2
         Configuration = "(H (1 [75] 4))"
      End
      Begin PaneConfiguration = 10
         NumPanes = 2
         Configuration = "(H (1[66] 2) )"
      End
      Begin PaneConfiguration = 11
         NumPanes = 2
         Configuration = "(H (4 [60] 2))"
      End
      Begin PaneConfiguration = 12
         NumPanes = 1
         Configuration = "(H (1) )"
      End
      Begin PaneConfiguration = 13
         NumPanes = 1
         Configuration = "(V (4))"
      End
      Begin PaneConfiguration = 14
         NumPanes = 1
         Configuration = "(V (2))"
      End
      ActivePaneConfig = 0
   End
   Begin DiagramPane = 
      Begin Origin = 
         Top = -240
         Left = -1923
      End
      Begin Tables = 
         Begin Table = "CT_CreditSource"
            Begin Extent = 
               Top = 7
               Left = 48
               Bottom = 558
               Right = 305
            End
            DisplayFlags = 280
            TopColumn = 2
         End
         Begin Table = "CT_Credit_text"
            Begin Extent = 
               Top = 1
               Left = 707
               Bottom = 676
               Right = 919
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "CT_Credit_file"
            Begin Extent = 
               Top = 9
               Left = 1183
               Bottom = 590
               Right = 1511
            End
            DisplayFlags = 280
            TopColumn = 0
         End
      End
   End
   Begin SQLPane = 
   End
   Begin DataPane = 
      Begin ParameterDefaults = ""
      End
   End
   Begin CriteriaPane = 
      Begin ColumnWidths = 11
         Column = 1440
         Alias = 900
         Table = 1170
         Output = 720
         Append = 1400
         NewValue = 1170
         SortType = 1350
         SortOrder = 1410
         GroupBy = 1350
         Filter = 1350
         Or = 1350
         Or = 1350
         Or = 1350
      End
   End
End
', 'SCHEMA', 'dbo', 'VIEW', 'View_ProductRecalls_File'
go

exec sp_addextendedproperty 'MS_DiagramPaneCount', 1, 'SCHEMA', 'dbo', 'VIEW', 'View_ProductRecalls_File'
go

