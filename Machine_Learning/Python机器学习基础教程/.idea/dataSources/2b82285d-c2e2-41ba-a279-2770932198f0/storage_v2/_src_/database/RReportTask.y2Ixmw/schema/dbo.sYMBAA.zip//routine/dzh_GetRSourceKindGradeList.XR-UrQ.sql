CREATE PROCEDURE [dbo].[dzh_GetRSourceKindGradeList]
AS

SELECT KindName FROM [RSKindGrade] ORDER BY KindGrade DESC
go

