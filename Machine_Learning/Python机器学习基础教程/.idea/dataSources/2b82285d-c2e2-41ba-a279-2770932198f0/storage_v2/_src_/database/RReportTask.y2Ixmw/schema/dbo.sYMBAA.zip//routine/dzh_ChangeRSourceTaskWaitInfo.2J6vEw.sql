CREATE PROCEDURE [dbo].[dzh_ChangeRSourceTaskWaitInfo]
@id int,
@status int,
@waittaskid int,
@account nvarchar(50)
AS

UPDATE [RSTask] SET Status=@status, InstituteId=@waittaskid WHERE ID=@id
UPDATE [RSTaskAppendix] SET Account=@account, UpdateTime=GETDATE() WHERE TaskId=@id
go

