
CREATE PROCEDURE [dbo].[DB_AUTO_CT_CgRecEvent_Creditlist_new]    
(                      
	@ID1 	int,
	@STATE	int,
	@LoginName VARCHAR(50)    
) AS        
-- =================================================                  
-- create date:2017-10-13    
-- AUTH:zhaomy  
-- =================================================    
 --获取输入日期与时间                
 --DECLARE @ENTRYDATE DATETIME                
 --SET @ENTRYDATE=CONVERT(VARCHAR(10),GETDATE(),120)                
 --DECLARE @ENTRYTIME VARCHAR(8)                
 --SET @ENTRYTIME=CONVERT(VARCHAR(8),GETDATE(),108)    
    
 DECLARE @OPERTYPE VARCHAR(1)    
     
 --数据储存开始                
 SET XACT_ABORT ON                  
 BEGIN TRAN FLAG

 UPDATE rreporttask..CT_CgRecEvent_Creditlist_new 
 SET STATE=@STATE
 --,
	-- EntryDate=@EntryDate,
	-- EntryTime=@EntryTime
 WHERE ID=@ID1
 IF @@ERROR<>0     
	BEGIN     
	RAISERROR('更新数据失败！',16,1)    
	ROLLBACK TRAN FLAG    
	RETURN @@ERROR    
 END  


 COMMIT TRAN FLAG    
 RETURN @@ERROR    
    
go

