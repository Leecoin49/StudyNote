CREATE PROCEDURE [dbo].[dzh_ClearImportData]
@account nvarchar(50)
AS

IF @account='zhangxiaohu'
	BEGIN
	TRUNCATE TABLE [RSDiscardReason]
	TRUNCATE TABLE [RSSimilarInfo]
	TRUNCATE TABLE [RSTask]
	TRUNCATE TABLE [RSTaskAppendix]
	
	UPDATE [RReportRaw].[dbo].[RReportRaw] SET Status=0
	
	--print 'Clear Import Data OK'
	--SET @return_value = 1
	return 1
	END
ELSE
	BEGIN
	--SET @return_value = 0
	return 0
	END
go

