--sp_helptext     DB_AUTO_ct_json_keywords

      
--============================================          
-- TBSTRU ct_json_keywords             
--============================================          
CREATE PROC [dbo].[DB_AUTO_ct_BCRAnn1_codemapping]          
(           
	@ID1      INT,   --流水号          
	@tablename	varchar(100),	--	表名
	@sitename	varchar(500),	--	网站名
	@sitesort	varchar(500),	--	目录名
	@CgRecEvent_BCRAnn1	varchar(500),	--	解析标题
	@BCRAnn1	varchar(500),	--	规范标题
	@state	int,	--	状态
	@url	varchar(500),	--	网址
	@LoginName  varchar(50) --登陆名                     
 )       
       
 AS          
      
      
  --获取输入日期与时间                            
 DECLARE @ENTRYDATE DATETIME                            
 SET @ENTRYDATE=CONVERT(VARCHAR(10),GETDATE(),120)                            
 DECLARE @ENTRYTIME VARCHAR(8)                            
 SET @ENTRYTIME=CONVERT(VARCHAR(8),GETDATE(),108)       
 
      
--数据储存开始          
SET XACT_ABORT ON            
BEGIN TRAN FLAG       
 
     
update ct_BCRAnn1_codemapping        
set      
tablename=case when @tablename='-1' then tablename else  @tablename end, 
sitename= case when @sitename='-1' then sitename else @sitename end,      
sitesort=case when @sitesort='-1' then sitesort else @sitesort end,  
CgRecEvent_BCRAnn1=case when @CgRecEvent_BCRAnn1='-1' then CgRecEvent_BCRAnn1 else @CgRecEvent_BCRAnn1 end, 
BCRAnn1=case when @BCRAnn1='-1' then BCRAnn1 else @BCRAnn1 end, 
State=case when @State='-999' then State else @State end, 
[url]=case when @url='-1' then url else @url end
 where ID=@ID1       
 IF @@ERROR <> 0                                          
  BEGIN                                         
   ROLLBACK TRAN FLAG                                          
   SELECT '更新ct_BCRAnn1_codemapping失败！',0                                         
   RETURN                         
  END        
      
       
 COMMIT TRAN FLAG       
 RETURN @@ERROR
go

