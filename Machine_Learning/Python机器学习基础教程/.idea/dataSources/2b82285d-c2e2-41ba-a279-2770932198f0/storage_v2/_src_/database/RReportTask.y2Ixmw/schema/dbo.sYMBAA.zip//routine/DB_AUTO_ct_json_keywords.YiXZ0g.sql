--sp_helptext     DB_AUTO_ct_json_keywords

      
--============================================          
-- TBSTRU ct_json_keywords             
--============================================          
CREATE PROC [dbo].[DB_AUTO_ct_json_keywords]          
(           
 @ID1      INT,   --流水号          
 @tablename varchar(100),--来源表 
 @sitename varchar(300), --网站     
 @sitesort varchar(300),--目录        
 @CgRecEvent_DataMid10 int , --来源     
 @key  varchar(500),  --代码  
 @key_sname  varchar(500),  --代码对应值     
 @State  int,  --状态 
 @url  varchar(500),  --网址     
 @LoginName  varchar(50) --登陆名                     
 )       
       
 AS          
      
      
  --获取输入日期与时间                            
 DECLARE @ENTRYDATE DATETIME                            
 SET @ENTRYDATE=CONVERT(VARCHAR(10),GETDATE(),120)                            
 DECLARE @ENTRYTIME VARCHAR(8)                            
 SET @ENTRYTIME=CONVERT(VARCHAR(8),GETDATE(),108)       
 
      
--数据储存开始          
SET XACT_ABORT ON            
BEGIN TRAN FLAG       
 
     
update ct_json_keywords       
set      
tablename=case when @tablename='-1' then tablename else  @tablename end, 
sitename= case when @sitename='-1' then sitename else @sitename end,      
sitesort=case when @sitesort='-1' then sitesort else @sitesort end,  
CgRecEvent_DataMid10=case when @CgRecEvent_DataMid10='-1' then CgRecEvent_DataMid10 else @CgRecEvent_DataMid10 end, 
[key]=case when @key='-1' then [key] else @key end, 
key_sname=case when @key_sname='-1' then key_sname else @key_sname end, 
State=case when @State='-999' then State else @State end, 
[url]=case when @url='-1' then url else @url end
 where id=@id1       
 IF @@ERROR <> 0                                          
  BEGIN                                         
   ROLLBACK TRAN FLAG                                          
   SELECT '更新ct_json_keywords失败！',0                                         
   RETURN                         
  END        
      
       
 COMMIT TRAN FLAG       
 RETURN @@ERROR
go

