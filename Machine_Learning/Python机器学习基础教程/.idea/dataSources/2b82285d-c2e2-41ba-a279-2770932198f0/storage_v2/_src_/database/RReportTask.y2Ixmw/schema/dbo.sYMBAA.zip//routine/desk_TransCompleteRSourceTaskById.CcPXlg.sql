CREATE PROCEDURE [dbo].[desk_TransCompleteRSourceTaskById]
@account nvarchar(50),
@taskid int,
@status int,
@fileid nvarchar(20)
AS

UPDATE [RSTaskAppendix] SET Account=@account, UpdateTime=getdate(), FileId=@fileid, UploadTime=getdate() WHERE TaskId=@taskid
UPDATE [RSTask] SET Status=@status WHERE ID=@taskid
go

