CREATE PROCEDURE [dbo].[Insert_CfpannounceMent]( 
@sitename varchar(200),--网站
@sitesort varchar(200),--目录
@url varchar(500),--链接
@title varchar(200),--标题
@dt DATETIME,--日期
@uniquecode varchar(50),--唯一编码
@content text,--内容
@systemno varchar(50),--编码
@memo varchar(10),--公开状态
@filelist varchar(200),--附件目录
@filename varchar(200),--附件名称
@fileurl varchar(500)--附件链接
) AS           
 --获取附件是否存在bool值
 DECLARE @isExists int     
 SET @isExists = (select count(1) from CT_CfpAnnounceMent with (nolock) where UNIQUECODE = @uniquecode)
        
 --数据储存开始       
 BEGIN
	if @fileurl = ''
		INSERT INTO [CT_CfpAnnounceMent] ([SITENAME],[SITESORT1],[URL],[TITLE],[DECLAREDATE],[STATE],[UNIQUECODE],[Content],[SYSTEMNO],[MEMO1]) VALUES ('[标签:网站]','[标签:目录]','[标签:链接]','[标签:标题]','[标签:日期]',0,'[标签:唯一编码]','[标签:内容]','[标签:编码]','[标签:公开状态]')
	else 
		INSERT INTO [CT_CfpAnnounceMent_file] ([DOWNFILELIST],[DOWNFILENAME],[STATE],[UNIQUECODE],[DOWNFILEURL]) VALUES ('[标签:附件目录]','[标签:附件名称]',0,'[标签:唯一编码]','[标签:附件链接]')
	if @fileurl != '' and @isExists = 0
		INSERT INTO [CT_CfpAnnounceMent] ([SITENAME],[SITESORT1],[URL],[TITLE],[DECLAREDATE],[STATE],[UNIQUECODE],[Content],[SYSTEMNO],[MEMO1]) VALUES ('[标签:网站]','[标签:目录]','[标签:链接]','[标签:标题]','[标签:日期]',0,'[标签:唯一编码]','[标签:内容]','[标签:编码]','[标签:公开状态]')
END
go

