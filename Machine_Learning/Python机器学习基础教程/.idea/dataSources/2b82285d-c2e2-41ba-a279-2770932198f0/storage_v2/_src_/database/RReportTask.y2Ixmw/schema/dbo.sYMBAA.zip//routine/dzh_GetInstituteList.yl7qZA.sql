CREATE PROCEDURE [dbo].[dzh_GetInstituteList]
AS

SELECT CompanyCode, RSR_Ins_Corr1 FROM [RSR_Ins_Corr] 
	GROUP BY CompanyCode, RSR_Ins_Corr1
	ORDER BY CompanyCode
go

