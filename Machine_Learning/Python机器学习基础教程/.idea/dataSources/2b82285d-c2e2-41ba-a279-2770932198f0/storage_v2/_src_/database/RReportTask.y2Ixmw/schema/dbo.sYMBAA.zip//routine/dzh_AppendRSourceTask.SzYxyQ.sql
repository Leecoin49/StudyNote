CREATE PROCEDURE [dbo].[dzh_AppendRSourceTask]
@rawid int,
@createtime datetime,
@publishtime datetime,
@reportdate datetime,
@titleraw nvarchar(256),
@titleshort nvarchar(256),
@institutename nvarchar(80),
--@instituteid int,
@institutecode varchar(8),
@author nvarchar(50),
@kindname nvarchar(50),
@kind2name nvarchar(50),
@stkcode nvarchar(20),
@stkname nvarchar(50),
@url nvarchar(1000),
@fileurl nvarchar(1000),
@fileurl_o nvarchar(1000),
@status int,
@taskid int output
AS

SELECT TOP 1 @taskid=ID FROM [RSTask] WHERE RawId=@rawid
IF @taskid is null
	BEGIN
	--IF @instituteid<=0 
	--	BEGIN
	--	DECLARE @instituteid1 int
	--	SELECT TOP 1 @instituteid1=InstituteId FROM [RSInstituteName] WHERE InstituteName=@institutename
	--	IF (@instituteid1 is not null) AND @instituteid1>0
	--		BEGIN
	--		SET @instituteid = @instituteid1
	--		END
	--	END
	IF (@institutecode IS NULL) OR @institutecode=''
		BEGIN
		DECLARE @institutecode1 varchar(8)
		SELECT TOP 1 @institutecode1=InstituteCode FROM [RSR_Ins_AliasName] WHERE InstituteName=@institutename AND (InstituteCode IS NOT NULL) AND InstituteCode<>''
		IF (@institutecode1 is not null) AND @institutecode1<>''
			BEGIN
			SET @institutecode = LTRIM(RTRIM(@institutecode1))
			END
		END
		
	INSERT [RSTask] (RawId, CreateTime, PublishTime, ReportDate, TitleRaw, TitleShort, InstituteName, InstituteId, Author, KindName, Kind2Name, StkCode, StkName, Url, FileUrl, FileUrl_o, Status, InstituteCode)
		VALUES (@rawid, @createtime, @publishtime, @reportdate, @titleraw, @titleshort, @institutename, 0, @author, @kindname, @kind2name, @stkcode, @stkname, @url, @fileurl, @fileurl_o, @status, @institutecode)
		
	--SET @taskid = @@IDENTITY
	SELECT TOP 1 @taskid=ID FROM [RSTask] WHERE RawId=@rawid
	END
--ELSE
--	BEGIN
--	END

IF NOT EXISTS (SELECT * FROM [RSTaskAppendix] WHERE TaskId=@taskid)
	BEGIN
	INSERT [RSTaskAppendix] (TaskId, FileName, FileMd5, FileLen, FileId, ReportId, Account, UpdateTime)
		VALUES (@taskid, '', '', 0, '', 0, '系统预处理新增', getdate())
	END
--ELSE
--	BEGIN
--	END
go

