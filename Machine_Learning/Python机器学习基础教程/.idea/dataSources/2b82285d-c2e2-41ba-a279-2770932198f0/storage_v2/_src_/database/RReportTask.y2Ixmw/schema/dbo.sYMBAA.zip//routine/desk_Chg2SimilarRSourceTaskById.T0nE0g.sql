CREATE PROCEDURE [dbo].[desk_Chg2SimilarRSourceTaskById]
@account nvarchar(50),
@taskid int,
@result nvarchar(256) output
AS

DECLARE @status1 int
DECLARE @account1 nvarchar(50)
SET @result = 'OK'

SELECT TOP 1 @status1=st.Status, @account1=ta.Account
	FROM [RSTask] st LEFT OUTER JOIN [RSTaskAppendix] ta ON st.Id=ta.TaskId
	WHERE st.ID=@taskid
	ORDER BY st.ID
	
IF @status1 is null
	BEGIN
	SET @result = '指定编号(=' + LTRIM(RTRIM(STR(@taskid))) + ')的研报源任务记录不存在'
	END
ELSE IF @status1<>13 AND @status1<>14 AND @status1<>43
	BEGIN
	SET @result = '指定编号(=' + LTRIM(RTRIM(STR(@taskid))) + ')的研报源任务记录当前状态(=' + LTRIM(RTRIM(STR(@status1))) + ')不是报废状态，不能重置为待处理'
	END
--ELSE IF @account1<>@account AND (@status1=41 OR @status1=45)
--	BEGIN
--	SET @result = '指定编号(=' + LTRIM(RTRIM(STR(@taskid))) + ')的研报源任务记录当前操作员不是您，您不能报废其他人正在处理的任务'
--	END
ELSE
	BEGIN
	SET @result = 'OK'
	UPDATE [RSTaskAppendix] SET Account=@account, UpdateTime=getdate(), FileName='', FileLen=0, FileId='', ReportId=0, FileMd5='' WHERE TaskId=@taskid
	UPDATE [RSTask] SET Status=40 WHERE ID=@taskid
	DELETE [RSDiscardReason] WHERE TaskId=@taskid
	
	SELECT st.ID, st.RawId, st.CreateTime, st.PublishTime, st.ReportDate, st.TitleRaw, st.TitleShort, st.InstituteName, st.InstituteCode, 
		st.InstituteId, st.Author, st.KindName, st.Kind2Name, st.StkCode, st.StkName, st.Url, st.FileUrl, st.FileUrl_o, st.Status, st.RawName, st.FileStatus, 
		ta.FileName, ta.FileMd5, ta.FileLen, ta.FileId, ta.ReportId, ta.Account, ta.UpdateTime,
		dr.SameReportId, dr.SameRemark,
		dbo.dzh_GetTaskSimilarInfo(st.ID) AS Similar
		FROM [RSTask] st LEFT OUTER JOIN [RSTaskAppendix] ta ON st.Id=ta.TaskId
		LEFT OUTER JOIN [RSDiscardReason] dr ON st.Id=dr.TaskId
		WHERE st.ID=@taskid
		ORDER BY st.ID
	END
go

