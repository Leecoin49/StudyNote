CREATE PROCEDURE [dbo].[pretreat_GetUnsettledRSourceTaskList]
@topnum int,
@againseconds int
AS

SELECT TOP(@topnum) st.ID, st.RawId, st.CreateTime, st.PublishTime, st.ReportDate, st.TitleRaw, st.TitleShort, st.InstituteName, 
	st.InstituteId, st.InstituteCode, st.Author, st.KindName, st.Kind2Name, st.StkCode, st.StkName, st.Url, st.FileUrl, st.FileUrl_o, st.Status, 
	st.RawName, st.FileStatus, 
	ta.FileName, ta.FileMd5, ta.FileLen, ta.FileId, ta.ReportId, ta.Account, ta.UpdateTime, 
	ta.Abstract,
	t1.IndustryCode, t1.IndustryName
	FROM [RSTask] st 
	LEFT OUTER JOIN [RSTaskAppendix] ta ON st.Id=ta.TaskId
	LEFT OUTER JOIN [RSTaskApp1] t1 ON st.Id=t1.TaskId
	WHERE st.Status=10 OR (st.Status=12 AND ta.UpdateTime<=DATEADD(second, 0-@againseconds, GETDATE()) AND st.CreateTime>=DATEADD(day, -3, GETDATE()))	
	--UpdateTime小于等于当前时间-60秒，也就是说，上次更新时间早于当前时间60秒
	ORDER BY st.Status, st.ID
go

