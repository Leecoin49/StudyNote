CREATE PROCEDURE [dbo].[dzh_GetRSourceInstituteGradeList]
AS

SELECT InstituteCode FROM [RSR_Ins_Grade] ORDER BY InstituteGrade DESC
go

