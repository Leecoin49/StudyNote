CREATE PROCEDURE [dbo].[dzh_UploadCompleteRSourceTaskById]
@account nvarchar(50),
@taskid int,
--@status int,	--2012.5.10 zxh 修改，不要传入新状态，由此存储过程自己决定更改后的状态
@fileid nvarchar(20),
@result nvarchar(256) output
AS

DECLARE @status1 int
DECLARE @account1 nvarchar(50)
SET @result = 'OK'

SELECT TOP 1 @status1=st.Status, @account1=ta.Account
	FROM [RSTask] st LEFT OUTER JOIN [RSTaskAppendix] ta ON st.Id=ta.TaskId
	WHERE st.ID=@taskid
	ORDER BY st.ID
	
IF @status1 is null
	BEGIN
	SET @result = '指定编号(=' + LTRIM(RTRIM(STR(@taskid))) + ')的研报源任务记录不存在'
	END
ELSE IF @account1<>@account
	BEGIN
	SET @result = '指定编号(=' + LTRIM(RTRIM(STR(@taskid))) + ')的研报源任务记录当前操作员不是您'
	END
ELSE IF @status1<>25 AND @status1<>26 AND @status1<>45 AND @status1<>46
	BEGIN
	SET @result = '指定编号(=' + LTRIM(RTRIM(STR(@taskid))) + ')的研报源任务记录当前状态(=' + LTRIM(RTRIM(STR(@status1))) + ')不是上传状态'
	END
--ELSE IF @status<>27 AND @status<>47
--	BEGIN
--	SET @result = '上传文件完成时，研报源任务记录只能跳转到27，47两种状态，不能跳转到 ' + LTRIM(RTRIM(STR(@status))) + ' 状态'
--	END
ELSE
	BEGIN
	DECLARE @status int
	IF @status1=25 OR @status1=26
		BEGIN
		SET @status = 27
		END
	ELSE
		BEGIN
		SET @status = 47
		END
		
	SET @result = 'OK'
	UPDATE [RSTaskAppendix] SET Account=@account, UpdateTime=getdate(), FileId=@fileid, UploadTime=getdate() WHERE TaskId=@taskid
	UPDATE [RSTask] SET Status=@status WHERE ID=@taskid
	
	SELECT st.ID, st.RawId, st.CreateTime, st.PublishTime, st.ReportDate, st.TitleRaw, st.TitleShort, st.InstituteName, st.InstituteCode, 
		st.InstituteId, st.Author, st.KindName, st.Kind2Name, st.StkCode, st.StkName, st.Url, st.FileUrl, st.FileUrl_o, st.Status, 
		ta.FileName, ta.FileMd5, ta.FileLen, ta.FileId, ta.ReportId, ta.Account, ta.UpdateTime,
		dr.SameReportId, dr.SameRemark,
		dbo.dzh_GetTaskSimilarInfo(st.ID) AS Similar
		FROM [RSTask] st LEFT OUTER JOIN [RSTaskAppendix] ta ON st.Id=ta.TaskId
		LEFT OUTER JOIN [RSDiscardReason] dr ON st.Id=dr.TaskId
		WHERE st.ID=@taskid
		ORDER BY st.ID
	END
go

