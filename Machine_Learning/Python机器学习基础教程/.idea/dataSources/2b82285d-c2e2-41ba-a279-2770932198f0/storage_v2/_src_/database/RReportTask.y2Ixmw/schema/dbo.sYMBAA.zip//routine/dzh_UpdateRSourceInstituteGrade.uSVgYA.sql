CREATE PROCEDURE [dbo].[dzh_UpdateRSourceInstituteGrade]
@maxcount int,
@institute varchar(4096)
AS

TRUNCATE TABLE [RSR_Ins_Grade]
WHILE(@institute <> '')   
	BEGIN
	DECLARE @nIndex INT
	
	SET @nIndex = CHARINDEX(',', @institute, 1)
	IF @nIndex>0
		BEGIN
		DECLARE @ch VARCHAR(50)
		SET @ch = LEFT(@institute, @nIndex-1)
		IF @ch<>''
			BEGIN
			INSERT [RSR_Ins_Grade] (InstituteCode, InstituteGrade) VALUES (@ch, @maxcount)
			SET @maxcount = @maxcount - 1
			END
		
		SET @institute = STUFF(@institute, 1, @nIndex, '')
		END
	ELSE
		BEGIN
		SET @institute = ''
		END
	END
go

