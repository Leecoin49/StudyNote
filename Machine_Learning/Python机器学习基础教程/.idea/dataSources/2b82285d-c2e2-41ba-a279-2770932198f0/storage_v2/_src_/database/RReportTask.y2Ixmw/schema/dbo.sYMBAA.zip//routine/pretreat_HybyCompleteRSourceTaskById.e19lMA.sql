CREATE PROCEDURE [dbo].[pretreat_HybyCompleteRSourceTaskById]
@taskid int,
@status int,
@reportid int
AS

UPDATE [RSTaskAppendix] SET Account='系统排重整合', UpdateTime=getdate(), FileId=LTRIM(RTRIM(STR(@reportid))), ReportId=@reportid, UploadTime=getdate() WHERE TaskId=@taskid
UPDATE [RSTask] SET Status=@status WHERE ID=@taskid
go

