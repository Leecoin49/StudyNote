CREATE VIEW dbo.View_EnvInfoDisclosure_Img
WITH SCHEMABINDING 
AS
SELECT  dbo.CT_Credit_img.id, dbo.CT_CreditSource.sitename, dbo.CT_CreditSource.sitesort, dbo.CT_CreditSource.submodule, 
                   dbo.CT_CreditSource.grabdatacode, dbo.CT_CreditSource.datasource, dbo.CT_Credit_img.sourceid, 
                   dbo.CT_Credit_img.parentguid, dbo.CT_EnvSoialGovern_Text.modulename, dbo.CT_EnvSoialGovern_Field.party, 
                   dbo.CT_EnvSoialGovern_Text.url, dbo.CT_Credit_img.url AS imgurl, dbo.CT_Credit_img.guid, dbo.CT_Credit_img.filepath, 
                   dbo.CT_Credit_img.relativepath, dbo.CT_Credit_img.state, dbo.CT_Credit_img.Entrydate, dbo.CT_Credit_img.Entrytime, 
                   dbo.CT_Credit_img.TMStamp
FROM      dbo.CT_CreditSource INNER JOIN
                   dbo.CT_EnvSoialGovern_Text ON dbo.CT_CreditSource.guid = dbo.CT_EnvSoialGovern_Text.sourceid INNER JOIN
                   dbo.CT_EnvSoialGovern_Field ON dbo.CT_EnvSoialGovern_Text.guid = dbo.CT_EnvSoialGovern_Field.guid INNER JOIN
                   dbo.CT_Credit_img ON dbo.CT_EnvSoialGovern_Text.guid = dbo.CT_Credit_img.parentguid
WHERE   (dbo.CT_CreditSource.modulecode = 305) AND (dbo.CT_CreditSource.submodule = '企业环境信息披露')
go

exec sp_addextendedproperty 'MS_DiagramPane1', N'[0E232FF0-B466-11cf-A24F-00AA00A3EFFF, 1.00]
Begin DesignProperties = 
   Begin PaneConfigurations = 
      Begin PaneConfiguration = 0
         NumPanes = 4
         Configuration = "(H (1[43] 4[52] 2[3] 3) )"
      End
      Begin PaneConfiguration = 1
         NumPanes = 3
         Configuration = "(H (1 [50] 4 [25] 3))"
      End
      Begin PaneConfiguration = 2
         NumPanes = 3
         Configuration = "(H (1 [50] 2 [25] 3))"
      End
      Begin PaneConfiguration = 3
         NumPanes = 3
         Configuration = "(H (4 [30] 2 [40] 3))"
      End
      Begin PaneConfiguration = 4
         NumPanes = 2
         Configuration = "(H (1 [56] 3))"
      End
      Begin PaneConfiguration = 5
         NumPanes = 2
         Configuration = "(H (2 [66] 3))"
      End
      Begin PaneConfiguration = 6
         NumPanes = 2
         Configuration = "(H (4 [50] 3))"
      End
      Begin PaneConfiguration = 7
         NumPanes = 1
         Configuration = "(V (3))"
      End
      Begin PaneConfiguration = 8
         NumPanes = 3
         Configuration = "(H (1[56] 4[18] 2) )"
      End
      Begin PaneConfiguration = 9
         NumPanes = 2
         Configuration = "(H (1 [75] 4))"
      End
      Begin PaneConfiguration = 10
         NumPanes = 2
         Configuration = "(H (1[66] 2) )"
      End
      Begin PaneConfiguration = 11
         NumPanes = 2
         Configuration = "(H (4 [60] 2))"
      End
      Begin PaneConfiguration = 12
         NumPanes = 1
         Configuration = "(H (1) )"
      End
      Begin PaneConfiguration = 13
         NumPanes = 1
         Configuration = "(V (4))"
      End
      Begin PaneConfiguration = 14
         NumPanes = 1
         Configuration = "(V (2))"
      End
      ActivePaneConfig = 0
   End
   Begin DiagramPane = 
      Begin Origin = 
         Top = 0
         Left = 0
      End
      Begin Tables = 
         Begin Table = "CT_CreditSource"
            Begin Extent = 
               Top = 7
               Left = 48
               Bottom = 336
               Right = 310
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "CT_EnvSoialGovern_Text"
            Begin Extent = 
               Top = 0
               Left = 576
               Bottom = 376
               Right = 1065
            End
            DisplayFlags = 280
            TopColumn = 6
         End
         Begin Table = "CT_EnvSoialGovern_Field"
            Begin Extent = 
               Top = 12
               Left = 1134
               Bottom = 358
               Right = 1483
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "CT_Credit_img"
            Begin Extent = 
               Top = 37
               Left = 1521
               Bottom = 464
               Right = 1972
            End
            DisplayFlags = 280
            TopColumn = 2
         End
      End
   End
   Begin SQLPane = 
   End
   Begin DataPane = 
      Begin ParameterDefaults = ""
      End
   End
   Begin CriteriaPane = 
      Begin ColumnWidths = 11
         Column = 1440
         Alias = 1812
         Table = 3288
         Output = 2580
         Append = 1400
         NewValue = 1170
         SortType = 1356
         SortOrder = 1416
         GroupBy = 1350
         Filter = 1356
         Or = 1350
         Or = 1350
         Or = 1350
      End
   End
End
', 'SCHEMA', 'dbo', 'VIEW', 'View_EnvInfoDisclosure_Img'
go

exec sp_addextendedproperty 'MS_DiagramPaneCount', 1, 'SCHEMA', 'dbo', 'VIEW', 'View_EnvInfoDisclosure_Img'
go

