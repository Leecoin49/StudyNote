
    
--============================================            
-- TBSTRU CT_MiningRightInfo_name           
--============================================        
CREATE PROC [dbo].[DB_AUTO_CT_MiningRightInfo_name]        
(         
@CompanyName varchar(500),--矿业权人
@state int,   --状态
@LoginName  varchar(50) --登陆名         
 ) AS        
    
    
DECLARE @ENTRYDATE VARCHAR(10)        
DECLARE @ENTRYTIME VARCHAR(8)        
SET @ENTRYDATE=CONVERT(VARCHAR(10),GETDATE(),120)        
SET @ENTRYTIME=CONVERT(VARCHAR(8),GETDATE(),108)        
    
    
--数据储存开始        
SET XACT_ABORT ON          
BEGIN TRAN FLAG     
    
INSERT INTO CT_MiningRightInfo_name(CompanyName,state,Entrydate,Entrytime)    
SELECT @CompanyName,@state,@Entrydate,@Entrytime  
IF @@ERROR <> 0                                              
  BEGIN                                             
   ROLLBACK TRAN FLAG                                              
   SELECT '新增CT_MiningRightInfo_name失败！',0                                             
   RETURN                             
  END     
    
     
 COMMIT TRAN FLAG     
 RETURN @@ERROR 
go

