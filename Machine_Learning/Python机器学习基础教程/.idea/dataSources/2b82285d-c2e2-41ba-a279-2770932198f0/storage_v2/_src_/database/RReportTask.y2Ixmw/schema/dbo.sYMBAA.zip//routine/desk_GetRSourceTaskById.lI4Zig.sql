CREATE PROCEDURE [dbo].[desk_GetRSourceTaskById]
@account nvarchar(50),
@taskid int
AS

SELECT st.ID, st.RawId, st.CreateTime, st.PublishTime, st.ReportDate, st.TitleRaw, st.TitleShort, st.InstituteName, st.InstituteCode, 
	st.InstituteId, st.Author, st.KindName, st.Kind2Name, st.StkCode, st.StkName, st.Url, st.FileUrl, st.FileUrl_o, st.Status, st.RawName, st.FileStatus, 
	ta.FileName, ta.FileMd5, ta.FileLen, ta.FileId, ta.ReportId, ta.Account, ta.UpdateTime,
	dr.SameReportId, dr.SameRemark,
	dbo.dzh_GetTaskSimilarInfo(st.ID) AS Similar
	FROM [RSTask] st LEFT OUTER JOIN [RSTaskAppendix] ta ON st.Id=ta.TaskId
	LEFT OUTER JOIN [RSDiscardReason] dr ON st.Id=dr.TaskId
	WHERE st.ID=@taskid
	ORDER BY st.ID
go

