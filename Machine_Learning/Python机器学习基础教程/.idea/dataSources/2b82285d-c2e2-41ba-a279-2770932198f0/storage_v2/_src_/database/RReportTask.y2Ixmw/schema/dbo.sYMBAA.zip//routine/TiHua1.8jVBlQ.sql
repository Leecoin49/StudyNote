

CREATE function [dbo].[TiHua1](@Name nvarchar(1000))  
returns nvarchar(max)  
as  
begin 
	declare @N int,@CName VARCHAR(100)
	set @N=1
	set @CName=''

	while substring(@Name,@N,1) in('0','1','2','3','4','5','6','7','8','9','.')
	begin 
		SET @CName=@CName+substring(@Name,@N,1)
		set @N=@N+1
	end 

	return @CName 	 
end
go

