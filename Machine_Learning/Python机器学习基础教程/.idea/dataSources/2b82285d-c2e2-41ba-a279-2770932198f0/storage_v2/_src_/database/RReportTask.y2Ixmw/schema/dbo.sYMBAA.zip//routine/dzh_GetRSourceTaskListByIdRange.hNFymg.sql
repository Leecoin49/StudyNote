CREATE PROCEDURE [dbo].[dzh_GetRSourceTaskListByIdRange]
@account nvarchar(50),
@minid int,
@maxid int
AS

SELECT st.ID, st.RawId, st.CreateTime, st.PublishTime, st.ReportDate, st.TitleRaw, st.TitleShort, st.InstituteName, st.InstituteCode, 
	st.InstituteId, st.Author, st.KindName, st.Kind2Name, st.StkCode, st.StkName, st.Url, st.FileUrl, st.FileUrl_o, st.Status, 
	ta.FileName, ta.FileMd5, ta.FileLen, ta.FileId, ta.ReportId, ta.Account, ta.UpdateTime,
	dr.SameReportId, dr.SameRemark,
	dbo.rst_GetTaskSimilarInfo(st.ID) AS Similar
	FROM [RSTask] st LEFT OUTER JOIN [RSTaskAppendix] ta ON st.Id=ta.TaskId
	LEFT OUTER JOIN [RSDiscardReason] dr ON st.Id=dr.TaskId
	WHERE st.ID>=@minid AND st.Id<=@maxid
	ORDER BY st.ID
go

