CREATE PROCEDURE [dbo].[dzh_AppendRSourceSimilarFile]
@id int,
@similarfile nvarchar(12),
@clearany int
AS

IF @clearany=1
	BEGIN
	DELETE [RSSimilarInfo] WHERE TaskId=@id AND (LikeType=2 OR (LikeId IS NULL) OR LikeId='')
	END
	
INSERT [RSSimilarInfo] (TaskId, LikeType, LikeId) VALUES (@id, 2, @similarfile)
go

