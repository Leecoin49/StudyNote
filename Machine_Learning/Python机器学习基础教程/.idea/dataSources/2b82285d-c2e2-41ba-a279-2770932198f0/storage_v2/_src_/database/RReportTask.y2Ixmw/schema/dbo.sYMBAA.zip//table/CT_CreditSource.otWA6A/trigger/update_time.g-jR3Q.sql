CREATE TRIGGER update_time ON dbo.CT_CreditSource
AFTER UPDATE 
AS
begin
    SET NOCOUNT ON;
    UPDATE RReportTask.dbo.CT_CreditSource
    SET updatetime = SYSDATETIME()
    WHERE ID IN (SELECT DISTINCT ID FROM inserted)
end;
go

