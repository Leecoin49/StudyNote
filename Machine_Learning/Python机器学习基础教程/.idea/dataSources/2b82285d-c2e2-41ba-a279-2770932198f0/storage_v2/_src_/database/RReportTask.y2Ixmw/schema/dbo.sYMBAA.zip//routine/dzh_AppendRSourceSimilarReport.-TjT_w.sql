CREATE PROCEDURE [dbo].[dzh_AppendRSourceSimilarReport]
@id int,
@similarreport int,
@clearany int
AS

IF @clearany=1
	BEGIN
	DELETE [RSSimilarInfo] WHERE TaskId=@id AND (LikeType=3 OR (LikeId IS NULL) OR LikeId='')
	END
	
INSERT [RSSimilarInfo] (TaskId, LikeType, LikeId) VALUES (@id, 3, LTRIM(RTRIM(STR(@similarreport))))
go

