
--select * from CT_iperunit
--[PInput_In_CT_iperunit] '11','11','11','11','2013-08-20','2013-08-20','23.56','','9865.125','dd','1','sss'
CREATE PROCEDURE [dbo].[PInput_In_CT_iperunit]( 
@SITENAME varchar(200),
@SITESORT1 varchar(200),
@URL varchar(1000),
@PTSNAME varchar(100),
@DeclareDate datetime,
@IPerUnit1 datetime,
@IPerUnit2 VARCHAR(30),
@IPerUnit3 VARCHAR(30),
@IPerUnit4 VARCHAR(30),
@SYSTEMNO varchar(20),
@STATE int,
@TextLink varchar(500)
) AS
   
 SET XACT_ABORT ON    
 BEGIN TRAN FLAG 
 
 --录入时间
 DECLARE @EntryDate DATETIME
 DECLARE @ENTRYTIME VARCHAR(10)
 SET @EntryDate=CONVERT(VARCHAR(10),GETDATE(),120)
 SET @ENTRYTIME=CONVERT(VARCHAR(10),GETDATE(),108)
 
IF ISNULL(@SITENAME,'')='' OR ISNULL(@SITESORT1,'')='' OR ISNULL(@URL,'')='' OR ISNULL(@PTSNAME,'')='' OR ISNULL(@SYSTEMNO,'')=''
BEGIN
ROLLBACK TRAN FLAG
SELECT '网站,目录一,网址,产品全称,系统编码不能为空',0
RETURN
END

IF (@IPerUnit2='' OR @IPerUnit2='-' OR @IPerUnit2='－') SET @IPerUnit2=NULL
IF (@IPerUnit3='' OR @IPerUnit3='-' OR @IPerUnit3='－') SET @IPerUnit3=NULL
IF (@IPerUnit4='' OR @IPerUnit4='-' OR @IPerUnit4='－') SET @IPerUnit4=NULL

INSERT INTO dbo.CT_iperunit (SITENAME,
SITESORT1,
URL,
PTSNAME,
DeclareDate,
IPerUnit1,
IPerUnit2,
IPerUnit3,
IPerUnit4,
SYSTEMNO,
STATE,
TextLink,
EntryDate,
EntryTime
) 
VALUES (@SITENAME,
@SITESORT1,
@URL,
@PTSNAME,
@DeclareDate,
@IPerUnit1,
@IPerUnit2,
@IPerUnit3,
@IPerUnit4,
@SYSTEMNO,
@STATE,
@TextLink,
@EntryDate,
@EntryTime
)

 COMMIT TRAN FLAG    
go

