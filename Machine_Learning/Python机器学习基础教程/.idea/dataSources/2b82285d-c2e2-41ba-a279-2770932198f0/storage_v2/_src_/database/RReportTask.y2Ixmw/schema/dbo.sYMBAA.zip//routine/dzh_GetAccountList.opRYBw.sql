CREATE PROCEDURE [dbo].[dzh_GetAccountList]
@account nvarchar(50)		--账号
AS

IF @account<>''
	BEGIN
	SELECT ac.* FROM [RSR_Accounts] ac 
		WHERE ac.Account=@account
		ORDER BY ac.Account
	END
ELSE
	BEGIN
	SELECT ac.* FROM [RSR_Accounts] ac 
		ORDER BY ac.Account
	END
go

