CREATE PROCEDURE [dbo].[desk_GetRSourceSimilarList]
@account nvarchar(50),
@taskid int
AS

SELECT st.ID, st.RawId, st.CreateTime, st.PublishTime, st.ReportDate, st.TitleRaw, st.TitleShort, st.InstituteName, st.InstituteCode, 
	st.InstituteId, st.Author, st.KindName, st.Kind2Name, st.StkCode, st.StkName, st.Url, st.FileUrl, st.FileUrl_o, st.Status, st.RawName, st.FileStatus, 
	ta.FileName, ta.FileMd5, ta.FileLen, ta.FileId, ta.ReportId, ta.Account, ta.UpdateTime,
	0 AS SameReportId, '' AS SameRemark,
	--'' AS Similar
	dbo.dzh_GetTaskSimilarInfo(st.ID) AS Similar
	FROM [RSTask] st LEFT OUTER JOIN [RSTaskAppendix] ta ON st.Id=ta.TaskId
	INNER JOIN [RSSimilarInfo] si ON st.Id=si.LikeId
	WHERE si.TaskId=@taskid AND si.LikeType=1
	ORDER BY st.ID
go

