

create function [dbo].[Ceshi](@c3 nvarchar(1000))  
returns nvarchar(max)  
as  
begin  

	declare @n int,@n1 int  
	set @n=1


	while len(substring(@c3,@n,1))>0 
	begin
		if patindex('%[吖-座]%',substring(@c3,@n,1) ) >0
		begin
			set @n1=1 
		end
		else 
		begin
			set @n1=2
		end
		set @n=@n+1 
	end

		return @n1 
	 
end

go

