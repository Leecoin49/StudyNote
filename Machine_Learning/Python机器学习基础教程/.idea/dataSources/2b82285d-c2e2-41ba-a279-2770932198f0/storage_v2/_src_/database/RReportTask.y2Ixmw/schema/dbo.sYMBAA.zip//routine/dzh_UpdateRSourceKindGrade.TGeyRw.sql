CREATE PROCEDURE [dbo].[dzh_UpdateRSourceKindGrade]
@maxcount int,
@kindname varchar(4096)
AS

TRUNCATE TABLE [RSKindGrade]
WHILE(@kindname <> '')   
	BEGIN
	DECLARE @nIndex INT
	
	SET @nIndex = CHARINDEX(',', @kindname, 1)
	IF @nIndex>0
		BEGIN
		DECLARE @ch VARCHAR(50)
		SET @ch = LEFT(@kindname, @nIndex-1)
		IF @ch<>''
			BEGIN
			INSERT [RSKindGrade] (KindName, KindGrade) VALUES (@ch, @maxcount)
			SET @maxcount = @maxcount - 1
			END
		
		SET @kindname = STUFF(@kindname, 1, @nIndex, '')
		END
	ELSE
		BEGIN
		SET @kindname = ''
		END
	END
go

