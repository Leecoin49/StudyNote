



  
            
-- =================================================          
       
-- is_proc_input_tb ct_ITPublicIns_nb,2        
-- DATE: 2022/8/17
-- =================================================                          
                          
CREATE PROCEDURE [dbo].[DB_AUTO_ct_ITPublicIns_nb_U]                          
(    @ID1 INT, --流水号      
     @state	varchar(200),	--状态
     @LoginName  varchar(50)                        
) AS                       
            
 ----获取存储日期时间                          
 --DECLARE @ENTRYDATE VARCHAR(10)                          
 --DECLARE @ENTRYTIME VARCHAR(8)                          
 --SET @ENTRYDATE=CONVERT(VARCHAR(10),GETDATE(),120)                          
 --SET @ENTRYTIME=CONVERT(VARCHAR(8),GETDATE(),108)                          
                           
 DECLARE @OPERTYPE VARCHAR(1)                          
                              
                
 --数据储存开始                          
 SET XACT_ABORT ON                            
 BEGIN TRAN FLAG                          
                          
    UPDATE ct_ITPublicIns_nb                   
    SET        
    state = @state                     
    WHERE ID=@ID1                       
    IF @@ERROR <> 0                       
  BEGIN                      
   ROLLBACK TRAN FLAG                       
   SELECT 'ct_ITPublicIns_nb更新失败,请联系管理员！',0                      
   RETURN                       
  END                       
                      
   SET @OPERTYPE='U'                      
                                   
             
 SELECT ''                      
 COMMIT TRAN FLAG                        
 RETURN 0   
go

