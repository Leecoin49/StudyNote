

--取数字 
CREATE function [dbo].[GetShuzi](@Name varchar(5000))  
returns nvarchar(max)  
as  
begin  
	while patindex('%[^0-9]%',@Name)>0
	begin
	set @Name=stuff(@Name,patindex('%[^0-9]%',@Name),1,'')
	end

	return @Name 
end





go

