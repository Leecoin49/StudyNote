--sp_helptext     DB_AUTO_HtmlMatch     
    
--============================================        
-- TBSTRU HtmlMatch           
--============================================        
CREATE PROC [dbo].[DB_AUTO_HtmlMatch]        
(         
 @ID1      INT,   --流水号        
 @FiledName nvarchar(50),    
 @ColumnHeader nvarchar(max),    
 @Type nvarchar(50),    
 @Flag int ,    
 @LoginName  varchar(50) --登陆名        
 )     
     
 AS        
    
    
 IF NOT EXISTS(SELECT * FROM rreporttask..HtmlMatch where ID=@ID1 and FiledName=@FiledName and Type =@Type)                          
 BEGIN                          
  RAISERROR('流水号与字段名任务名不符',16,1)                          
  RETURN @@ERROR                          
 END                  
 
                
                 
    
    
--数据储存开始        
SET XACT_ABORT ON          
BEGIN TRAN FLAG     
    
update HtmlMatch     
set    
FiledName =@FiledName,  
--case when @FiledName=-1 then FiledName else @FiledName end,    
ColumnHeader =case when @ColumnHeader='-1' then ColumnHeader else @ColumnHeader end,    
Type =@Type,  
--case when @Type='-1' then Type else @Type end ,    
Flag =case when @Flag=-1 then Flag else @Flag end     
 where id=@id1     
 IF @@ERROR <> 0                                        
  BEGIN                                       
   ROLLBACK TRAN FLAG                                        
   SELECT '更新HtmlMatch失败！',0                                       
   RETURN                       
  END      
    
     
 COMMIT TRAN FLAG     
 RETURN @@ERROR
go

