CREATE PROCEDURE [dbo].[desk_GetRSourceTaskListAttr]
@topnum int,
@account nvarchar(50),
@attr nvarchar(50)
AS

IF @topnum<=0
	BEGIN
	SET @topnum = 100000
	END
	
IF @attr='Different'		--完全不同待处理
	BEGIN
	SELECT TOP(@topnum) st.ID, st.RawId, st.CreateTime, st.PublishTime, st.ReportDate, st.TitleRaw, st.TitleShort, st.InstituteName, st.InstituteCode, 
		st.InstituteId, st.Author, st.KindName, st.Kind2Name, st.StkCode, st.StkName, st.Url, st.FileUrl, st.FileUrl_o, st.Status, st.RawName, st.FileStatus, 
		ta.FileName, ta.FileMd5, ta.FileLen, ta.FileId, ta.ReportId, ta.Account, ta.UpdateTime,
		dr.SameReportId, dr.SameRemark,
		dbo.dzh_GetTaskSimilarInfo(st.ID) AS Similar
		FROM [RSTask] st LEFT OUTER JOIN [RSTaskAppendix] ta ON st.Id=ta.TaskId
		LEFT OUTER JOIN [RSDiscardReason] dr ON st.Id=dr.TaskId
		LEFT OUTER JOIN [RSKindGrade] kg ON st.KindName=kg.KindName
		LEFT OUTER JOIN [RSR_Ins_Grade] ig ON st.InstituteCode=ig.InstituteCode
		WHERE st.Status=20 OR (st.Status=21 AND ta.Account=@account)
		--ORDER BY st.ID
		ORDER BY kg.KindGrade DESC, ig.InstituteGrade DESC
	END
ELSE IF @attr='Similar'		--疑似相同待处理
	BEGIN
	SELECT TOP(@topnum) st.ID, st.RawId, st.CreateTime, st.PublishTime, st.ReportDate, st.TitleRaw, st.TitleShort, st.InstituteName, st.InstituteCode, 
		st.InstituteId, st.Author, st.KindName, st.Kind2Name, st.StkCode, st.StkName, st.Url, st.FileUrl, st.FileUrl_o, st.Status, st.RawName, st.FileStatus, 
		ta.FileName, ta.FileMd5, ta.FileLen, ta.FileId, ta.ReportId, ta.Account, ta.UpdateTime,
		dr.SameReportId, dr.SameRemark,
		dbo.dzh_GetTaskSimilarInfo(st.ID) AS Similar
		FROM [RSTask] st LEFT OUTER JOIN [RSTaskAppendix] ta ON st.Id=ta.TaskId
		LEFT OUTER JOIN [RSDiscardReason] dr ON st.Id=dr.TaskId
		LEFT OUTER JOIN [RSKindGrade] kg ON st.KindName=kg.KindName
		LEFT OUTER JOIN [RSR_Ins_Grade] ig ON st.InstituteCode=ig.InstituteCode
		WHERE st.Status=40 OR (st.Status=41 AND ta.Account=@account)
		--ORDER BY st.ID
		ORDER BY kg.KindGrade DESC, ig.InstituteGrade DESC
	END
ELSE IF @attr='Dnload'		--正在下载、下载完成
	BEGIN
	SELECT TOP(@topnum) st.ID, st.RawId, st.CreateTime, st.PublishTime, st.ReportDate, st.TitleRaw, st.TitleShort, st.InstituteName, st.InstituteCode, 
		st.InstituteId, st.Author, st.KindName, st.Kind2Name, st.StkCode, st.StkName, st.Url, st.FileUrl, st.FileUrl_o, st.Status, st.RawName, st.FileStatus, 
		ta.FileName, ta.FileMd5, ta.FileLen, ta.FileId, ta.ReportId, ta.Account, ta.UpdateTime,
		dr.SameReportId, dr.SameRemark,
		dbo.dzh_GetTaskSimilarInfo(st.ID) AS Similar
		FROM [RSTask] st LEFT OUTER JOIN [RSTaskAppendix] ta ON st.Id=ta.TaskId
		LEFT OUTER JOIN [RSDiscardReason] dr ON st.Id=dr.TaskId
		--2012.7.10 zxh 修改，这些列表不按类别和机构优先级排名，按操作时间倒序排
		--LEFT OUTER JOIN [RSKindGrade] kg ON st.KindName=kg.KindName
		--LEFT OUTER JOIN [RSR_Ins_Grade] ig ON st.InstituteCode=ig.InstituteCode
		WHERE (st.Status=22 OR st.Status=24 OR st.Status=25 OR st.Status=42 OR st.Status=44 OR st.Status=45) AND ta.Account=@account
		----ORDER BY st.ID
		--ORDER BY kg.KindGrade DESC, ig.InstituteGrade DESC
		--2012.7.10 zxh 修改，注释掉上面这段，修改成下面这一句
		ORDER BY ta.UpdateTime DESC
	END
ELSE IF @attr='Upload'		--正在上传，上传完成，录入完成
	BEGIN
	SELECT TOP(@topnum) st.ID, st.RawId, st.CreateTime, st.PublishTime, st.ReportDate, st.TitleRaw, st.TitleShort, st.InstituteName, st.InstituteCode, 
		st.InstituteId, st.Author, st.KindName, st.Kind2Name, st.StkCode, st.StkName, st.Url, st.FileUrl, st.FileUrl_o, st.Status, st.RawName, st.FileStatus, 
		ta.FileName, ta.FileMd5, ta.FileLen, ta.FileId, ta.ReportId, ta.Account, ta.UpdateTime,
		dr.SameReportId, dr.SameRemark,
		dbo.dzh_GetTaskSimilarInfo(st.ID) AS Similar
		FROM [RSTask] st LEFT OUTER JOIN [RSTaskAppendix] ta ON st.Id=ta.TaskId
		LEFT OUTER JOIN [RSDiscardReason] dr ON st.Id=dr.TaskId
		--2012.7.10 zxh 修改，这些列表不按类别和机构优先级排名，按操作时间倒序排
		--LEFT OUTER JOIN [RSKindGrade] kg ON st.KindName=kg.KindName
		--LEFT OUTER JOIN [RSR_Ins_Grade] ig ON st.InstituteCode=ig.InstituteCode
		WHERE (st.Status=26 OR st.Status=27 OR st.Status=28 OR st.Status=46 OR st.Status=47 OR st.Status=48) AND ta.Account=@account
		----ORDER BY st.ID DESC
		--ORDER BY kg.KindGrade DESC, ig.InstituteGrade DESC
		--2012.7.10 zxh 修改，注释掉上面这段，修改成下面这一句
		ORDER BY ta.UpdateTime DESC
	END
ELSE IF @attr='Downloading'	--正在下载
	BEGIN
	SELECT TOP(@topnum) st.ID, st.RawId, st.CreateTime, st.PublishTime, st.ReportDate, st.TitleRaw, st.TitleShort, st.InstituteName, st.InstituteCode, 
		st.InstituteId, st.Author, st.KindName, st.Kind2Name, st.StkCode, st.StkName, st.Url, st.FileUrl, st.FileUrl_o, st.Status, st.RawName, st.FileStatus, 
		ta.FileName, ta.FileMd5, ta.FileLen, ta.FileId, ta.ReportId, ta.Account, ta.UpdateTime,
		dr.SameReportId, dr.SameRemark,
		dbo.dzh_GetTaskSimilarInfo(st.ID) AS Similar
		FROM [RSTask] st LEFT OUTER JOIN [RSTaskAppendix] ta ON st.Id=ta.TaskId
		LEFT OUTER JOIN [RSDiscardReason] dr ON st.Id=dr.TaskId
		--2012.7.10 zxh 修改，这些列表不按类别和机构优先级排名，按操作时间倒序排
		--LEFT OUTER JOIN [RSKindGrade] kg ON st.KindName=kg.KindName
		--LEFT OUTER JOIN [RSR_Ins_Grade] ig ON st.InstituteCode=ig.InstituteCode
		WHERE (st.Status=22 OR st.Status=24 OR st.Status=42 OR st.Status=44) AND ta.Account=@account
		----ORDER BY st.ID
		--ORDER BY kg.KindGrade DESC, ig.InstituteGrade DESC
		--2012.7.10 zxh 修改，注释掉上面这段，修改成下面这一句
		ORDER BY ta.UpdateTime DESC
	END
ELSE IF @attr='DownloadOK'	--下载完成
	BEGIN
	SELECT TOP(@topnum) st.ID, st.RawId, st.CreateTime, st.PublishTime, st.ReportDate, st.TitleRaw, st.TitleShort, st.InstituteName, st.InstituteCode, 
		st.InstituteId, st.Author, st.KindName, st.Kind2Name, st.StkCode, st.StkName, st.Url, st.FileUrl, st.FileUrl_o, st.Status, st.RawName, st.FileStatus, 
		ta.FileName, ta.FileMd5, ta.FileLen, ta.FileId, ta.ReportId, ta.Account, ta.UpdateTime,
		dr.SameReportId, dr.SameRemark,
		dbo.dzh_GetTaskSimilarInfo(st.ID) AS Similar
		FROM [RSTask] st LEFT OUTER JOIN [RSTaskAppendix] ta ON st.Id=ta.TaskId
		LEFT OUTER JOIN [RSDiscardReason] dr ON st.Id=dr.TaskId
		--2012.7.10 zxh 修改，这些列表不按类别和机构优先级排名，按操作时间倒序排
		--LEFT OUTER JOIN [RSKindGrade] kg ON st.KindName=kg.KindName
		--LEFT OUTER JOIN [RSR_Ins_Grade] ig ON st.InstituteCode=ig.InstituteCode
		WHERE (st.Status=25 OR st.Status=45) AND ta.Account=@account
		----ORDER BY st.ID
		--ORDER BY kg.KindGrade DESC, ig.InstituteGrade DESC
		--2012.7.10 zxh 修改，注释掉上面这段，修改成下面这一句
		ORDER BY ta.UpdateTime DESC
	END
ELSE IF @attr='Uploading'	--正在上传
	BEGIN
	SELECT TOP(@topnum) st.ID, st.RawId, st.CreateTime, st.PublishTime, st.ReportDate, st.TitleRaw, st.TitleShort, st.InstituteName, st.InstituteCode, 
		st.InstituteId, st.Author, st.KindName, st.Kind2Name, st.StkCode, st.StkName, st.Url, st.FileUrl, st.FileUrl_o, st.Status, st.RawName, st.FileStatus, 
		ta.FileName, ta.FileMd5, ta.FileLen, ta.FileId, ta.ReportId, ta.Account, ta.UpdateTime,
		dr.SameReportId, dr.SameRemark,
		dbo.dzh_GetTaskSimilarInfo(st.ID) AS Similar
		FROM [RSTask] st LEFT OUTER JOIN [RSTaskAppendix] ta ON st.Id=ta.TaskId
		LEFT OUTER JOIN [RSDiscardReason] dr ON st.Id=dr.TaskId
		--2012.7.10 zxh 修改，这些列表不按类别和机构优先级排名，按操作时间倒序排
		--LEFT OUTER JOIN [RSKindGrade] kg ON st.KindName=kg.KindName
		--LEFT OUTER JOIN [RSR_Ins_Grade] ig ON st.InstituteCode=ig.InstituteCode
		WHERE (st.Status=26 OR st.Status=46) AND ta.Account=@account AND ta.UpdateTime>=DateAdd(day, -1, getdate())
		----ORDER BY st.ID
		--ORDER BY kg.KindGrade DESC, ig.InstituteGrade DESC
		--2012.7.10 zxh 修改，注释掉上面这段，修改成下面这一句
		ORDER BY ta.UpdateTime DESC
	END
ELSE IF @attr='UploadOK'	--上传完成
	BEGIN
	SELECT TOP(@topnum) st.ID, st.RawId, st.CreateTime, st.PublishTime, st.ReportDate, st.TitleRaw, st.TitleShort, st.InstituteName, st.InstituteCode, 
		st.InstituteId, st.Author, st.KindName, st.Kind2Name, st.StkCode, st.StkName, st.Url, st.FileUrl, st.FileUrl_o, st.Status, st.RawName, st.FileStatus, 
		ta.FileName, ta.FileMd5, ta.FileLen, ta.FileId, ta.ReportId, ta.Account, ta.UpdateTime,
		dr.SameReportId, dr.SameRemark,
		dbo.dzh_GetTaskSimilarInfo(st.ID) AS Similar
		FROM [RSTask] st LEFT OUTER JOIN [RSTaskAppendix] ta ON st.Id=ta.TaskId
		LEFT OUTER JOIN [RSDiscardReason] dr ON st.Id=dr.TaskId
		--2012.7.10 zxh 修改，这些列表不按类别和机构优先级排名，按操作时间倒序排
		--LEFT OUTER JOIN [RSKindGrade] kg ON st.KindName=kg.KindName
		--LEFT OUTER JOIN [RSR_Ins_Grade] ig ON st.InstituteCode=ig.InstituteCode
		WHERE (st.Status=27 OR st.Status=47) --AND ta.Account=@account
		----ORDER BY st.ID
		--ORDER BY kg.KindGrade DESC, ig.InstituteGrade DESC
		--2012.7.10 zxh 修改，注释掉上面这段，修改成下面这一句
		ORDER BY ta.UpdateTime DESC
	END
ELSE IF @attr='InputOK'		--录入完成
	BEGIN
	SELECT TOP(@topnum) st.ID, st.RawId, st.CreateTime, st.PublishTime, st.ReportDate, st.TitleRaw, st.TitleShort, st.InstituteName, st.InstituteCode, 
		st.InstituteId, st.Author, st.KindName, st.Kind2Name, st.StkCode, st.StkName, st.Url, st.FileUrl, st.FileUrl_o, st.Status, st.RawName, st.FileStatus, 
		ta.FileName, ta.FileMd5, ta.FileLen, ta.FileId, ta.ReportId, ta.Account, ta.UpdateTime,
		dr.SameReportId, dr.SameRemark,
		dbo.dzh_GetTaskSimilarInfo(st.ID) AS Similar
		FROM [RSTask] st LEFT OUTER JOIN [RSTaskAppendix] ta ON st.Id=ta.TaskId
		LEFT OUTER JOIN [RSDiscardReason] dr ON st.Id=dr.TaskId
		--2012.7.10 zxh 修改，这些列表不按类别和机构优先级排名，按操作时间倒序排
		--LEFT OUTER JOIN [RSKindGrade] kg ON st.KindName=kg.KindName
		--LEFT OUTER JOIN [RSR_Ins_Grade] ig ON st.InstituteCode=ig.InstituteCode
		WHERE st.Status=28 OR st.Status=48
		----ORDER BY st.ID DESC	--录入完成的反向排序
		--ORDER BY kg.KindGrade DESC, ig.InstituteGrade DESC
		--2012.7.10 zxh 修改，注释掉上面这段，修改成下面这一句
		ORDER BY ta.UpdateTime DESC
	END
ELSE IF @attr='Discard'		--报废
	BEGIN
	SELECT TOP(@topnum) st.ID, st.RawId, st.CreateTime, st.PublishTime, st.ReportDate, st.TitleRaw, st.TitleShort, st.InstituteName, st.InstituteCode, 
		st.InstituteId, st.Author, st.KindName, st.Kind2Name, st.StkCode, st.StkName, st.Url, st.FileUrl, st.FileUrl_o, st.Status, st.RawName, st.FileStatus, 
		ta.FileName, ta.FileMd5, ta.FileLen, ta.FileId, ta.ReportId, ta.Account, ta.UpdateTime,
		dr.SameReportId, dr.SameRemark,
		dbo.dzh_GetTaskSimilarInfo(st.ID) AS Similar
		FROM [RSTask] st LEFT OUTER JOIN [RSTaskAppendix] ta ON st.Id=ta.TaskId
		LEFT OUTER JOIN [RSDiscardReason] dr ON st.Id=dr.TaskId
		--2012.7.10 zxh 修改，这些列表不按类别和机构优先级排名，按操作时间倒序排
		--LEFT OUTER JOIN [RSKindGrade] kg ON st.KindName=kg.KindName
		--LEFT OUTER JOIN [RSR_Ins_Grade] ig ON st.InstituteCode=ig.InstituteCode
		WHERE st.Status=13 OR st.Status=14 OR st.Status=43
		----ORDER BY st.ID DESC	--报废的反向排序
		--ORDER BY kg.KindGrade DESC, ig.InstituteGrade DESC
		--2012.7.10 zxh 修改，注释掉上面这段，修改成下面这一句
		ORDER BY ta.UpdateTime DESC
	END
ELSE IF @attr='DiscardAuto'	--自动报废
	BEGIN
	SELECT TOP(@topnum) st.ID, st.RawId, st.CreateTime, st.PublishTime, st.ReportDate, st.TitleRaw, st.TitleShort, st.InstituteName, st.InstituteCode, 
		st.InstituteId, st.Author, st.KindName, st.Kind2Name, st.StkCode, st.StkName, st.Url, st.FileUrl, st.FileUrl_o, st.Status, st.RawName, st.FileStatus, 
		ta.FileName, ta.FileMd5, ta.FileLen, ta.FileId, ta.ReportId, ta.Account, ta.UpdateTime,
		dr.SameReportId, dr.SameRemark,
		dbo.dzh_GetTaskSimilarInfo(st.ID) AS Similar
		FROM [RSTask] st LEFT OUTER JOIN [RSTaskAppendix] ta ON st.Id=ta.TaskId
		LEFT OUTER JOIN [RSDiscardReason] dr ON st.Id=dr.TaskId
		--2012.7.10 zxh 修改，这些列表不按类别和机构优先级排名，按操作时间倒序排
		--LEFT OUTER JOIN [RSKindGrade] kg ON st.KindName=kg.KindName
		--LEFT OUTER JOIN [RSR_Ins_Grade] ig ON st.InstituteCode=ig.InstituteCode
		WHERE st.Status=13 OR st.Status=14
		----ORDER BY st.ID DESC	--报废的反向排序
		--ORDER BY kg.KindGrade DESC, ig.InstituteGrade DESC
		--2012.7.10 zxh 修改，注释掉上面这段，修改成下面这一句
		ORDER BY ta.UpdateTime DESC
	END
ELSE IF @attr='DiscardMan'	--人工报废
	BEGIN
	SELECT TOP(@topnum) st.ID, st.RawId, st.CreateTime, st.PublishTime, st.ReportDate, st.TitleRaw, st.TitleShort, st.InstituteName, st.InstituteCode, 
		st.InstituteId, st.Author, st.KindName, st.Kind2Name, st.StkCode, st.StkName, st.Url, st.FileUrl, st.FileUrl_o, st.Status, st.RawName, st.FileStatus, 
		ta.FileName, ta.FileMd5, ta.FileLen, ta.FileId, ta.ReportId, ta.Account, ta.UpdateTime,
		dr.SameReportId, dr.SameRemark,
		dbo.dzh_GetTaskSimilarInfo(st.ID) AS Similar
		FROM [RSTask] st LEFT OUTER JOIN [RSTaskAppendix] ta ON st.Id=ta.TaskId
		LEFT OUTER JOIN [RSDiscardReason] dr ON st.Id=dr.TaskId
		--2012.7.10 zxh 修改，这些列表不按类别和机构优先级排名，按操作时间倒序排
		--LEFT OUTER JOIN [RSKindGrade] kg ON st.KindName=kg.KindName
		--LEFT OUTER JOIN [RSR_Ins_Grade] ig ON st.InstituteCode=ig.InstituteCode
		WHERE st.Status=43
		----ORDER BY st.ID DESC	--报废的反向排序
		--ORDER BY kg.KindGrade DESC, ig.InstituteGrade DESC
		--2012.7.10 zxh 修改，注释掉上面这段，修改成下面这一句
		ORDER BY ta.UpdateTime DESC
	END
ELSE IF @attr='recent'		--最近
	BEGIN
	IF @topnum>2000
		BEGIN
		SET @topnum = 2000
		END
	SELECT TOP(@topnum) st.ID, st.RawId, st.CreateTime, st.PublishTime, st.ReportDate, st.TitleRaw, st.TitleShort, st.InstituteName, st.InstituteCode, 
		st.InstituteId, st.Author, st.KindName, st.Kind2Name, st.StkCode, st.StkName, st.Url, st.FileUrl, st.FileUrl_o, st.Status, st.RawName, st.FileStatus, 
		ta.FileName, ta.FileMd5, ta.FileLen, ta.FileId, ta.ReportId, ta.Account, ta.UpdateTime,
		dr.SameReportId, dr.SameRemark,
		dbo.dzh_GetTaskSimilarInfo(st.ID) AS Similar
		FROM [RSTask] st LEFT OUTER JOIN [RSTaskAppendix] ta ON st.Id=ta.TaskId
		LEFT OUTER JOIN [RSDiscardReason] dr ON st.Id=dr.TaskId
		--2012.7.10 zxh 修改，这些列表不按类别和机构优先级排名，按操作时间倒序排
		--LEFT OUTER JOIN [RSKindGrade] kg ON st.KindName=kg.KindName
		--LEFT OUTER JOIN [RSR_Ins_Grade] ig ON st.InstituteCode=ig.InstituteCode
		----ORDER BY st.ID DESC	--报废的反向排序
		--ORDER BY kg.KindGrade DESC, ig.InstituteGrade DESC
		--2012.7.10 zxh 修改，注释掉上面这段，修改成下面这一句
		ORDER BY ta.UpdateTime DESC
	END
ELSE
	BEGIN
	SELECT st.ID FROM [RSTask] st WHERE 1=0
	END
go

