



  
            
-- =================================================          
       
-- is_proc_input_tb Ct_default_values,2        
-- DATE: 2023/8/4
-- =================================================                          
                          
CREATE PROCEDURE [dbo].[DB_AUTO_Ct_default_values_U]                          
(    @ID1 INT, --流水号      
     @Sitename	varchar(200),	--网站
     @Sitesort	varchar(200),	--目录
     @CompanyQUALInfo2	varchar(200),  --资质名称
     @CompanyQUALInfo7	int,  --变动类别
     @DataSource	int,                --来源      
     @CompanyQUALInfo9	int,			--公告表ID
     @CompanyQUALAnn5	int,			--Ann来源
     @CompanyQUALAnn6	varchar(100),	--来源（披露）
     @NeedAnn	int,					--是否需解析公告表
     @NeedFile	int,					--是否需解析附件表
     @DataType	varchar(20),			--数据样式
     @Send_FileType	varchar(50),		--业务类型
     @Send_HtmlModule	varchar(50),	--模板类型
     @state	int,						--状态
     @CompanyQUALInfo4	varchar(500),	--发证机关
     @LoginName  varchar(50)                        
) AS                       
            
 --获取存储日期时间                          
 DECLARE @ENTRYDATE VARCHAR(10)                          
 DECLARE @ENTRYTIME VARCHAR(8)                          
 SET @ENTRYDATE=CONVERT(VARCHAR(10),GETDATE(),120)                          
 SET @ENTRYTIME=CONVERT(VARCHAR(8),GETDATE(),108)                          
                           
 DECLARE @OPERNeedFile VARCHAR(1)                          
                              
                
 --数据储存开始                          
 SET XACT_ABORT ON                            
 BEGIN TRAN FLAG                          
                          
    UPDATE Ct_default_values                   
    SET        
    Sitename =CASE WHEN @Sitename='-1' THEN Sitename ELSE @Sitename END,       
    Sitesort =CASE WHEN @Sitesort='-1' THEN Sitesort ELSE @Sitesort END,                       
    CompanyQUALInfo2 =CASE WHEN @CompanyQUALInfo2='-1' THEN CompanyQUALInfo2 ELSE @CompanyQUALInfo2 END,       
    CompanyQUALInfo7 =CASE WHEN @CompanyQUALInfo7='-1' THEN CompanyQUALInfo7 ELSE @CompanyQUALInfo7 END,       
    DataSource =CASE WHEN @DataSource='-1' THEN DataSource ELSE @DataSource END,         
    CompanyQUALInfo9 =CASE WHEN @CompanyQUALInfo9='-1' THEN CompanyQUALInfo9 ELSE @CompanyQUALInfo9 END,         
    CompanyQUALAnn5 =CASE WHEN @CompanyQUALAnn5='-1' THEN CompanyQUALAnn5 ELSE @CompanyQUALAnn5 END,   
    CompanyQUALAnn6 =CASE WHEN @CompanyQUALAnn6='-1' THEN CompanyQUALAnn6 ELSE @CompanyQUALAnn6 END, 
    NeedAnn =CASE WHEN @NeedAnn='-1' THEN NeedAnn ELSE @NeedAnn END, 
    NeedFile =CASE WHEN @NeedFile='-999' THEN NeedFile ELSE @NeedFile END,      
    DataType =CASE WHEN @DataType='-1' THEN DataType ELSE @DataType END,         
    Send_FileType =CASE WHEN @Send_FileType='-1' THEN Send_FileType ELSE @Send_FileType END,                       
    Send_HtmlModule=CASE WHEN @Send_HtmlModule='-1' THEN Send_HtmlModule ELSE @Send_HtmlModule END,
    state =CASE WHEN @state='-1' THEN state ELSE @state END,      
    CompanyQUALInfo4 =CASE WHEN @CompanyQUALInfo4='-1' THEN CompanyQUALInfo4 ELSE @CompanyQUALInfo4 END,  
    ENTRYDATE=@ENTRYDATE,                      
    ENTRYTIME=@ENTRYTIME                       
    WHERE ID=@ID1                       
    IF @@ERROR <> 0                       
  BEGIN                      
   ROLLBACK TRAN FLAG                       
   SELECT 'Ct_default_values更新失败,请联系管理员！',0                      
   RETURN                       
  END                       
                      
   SET @OPERNeedFile='U'                      
                           
 ------记录Inputlog信息                      
 --IF @OPERNeedFile='U'                      
 --BEGIN                       
 -- INSERT INTO InputLog(TBName,TBKeys,UpTime,OperNeedFile,OperUser,ToolName,[Status])                      
 -- VALUES('Ct_default_values',CAST(@ID1 AS VARCHAR),GETDATE(),@OPERNeedFile,@LoginName,'DB_AUTO',1)                      
 -- IF @@ERROR <> 0                       
 -- BEGIN                      
 --  ROLLBACK TRAN FLAG                       
 --  SELECT 'Inputlog表中新增记录失败，请联系管理员！',@ID1                      
 --  RETURN                       
 -- END                       
 --END           
             
 SELECT ''                      
 COMMIT TRAN FLAG                        
 RETURN 0   
go

