CREATE PROCEDURE [dbo].[dzh_AppendRSourceSimilarTask]
@id int,
@similartask int,
@clearany int
AS

IF @clearany=1
	BEGIN
	DELETE [RSSimilarInfo] WHERE TaskId=@id AND (LikeType=1 OR (LikeId IS NULL) OR LikeId='')
	END
	
INSERT [RSSimilarInfo] (TaskId, LikeType, LikeId) VALUES (@id, 1, LTRIM(RTRIM(STR(@similartask))))
go

