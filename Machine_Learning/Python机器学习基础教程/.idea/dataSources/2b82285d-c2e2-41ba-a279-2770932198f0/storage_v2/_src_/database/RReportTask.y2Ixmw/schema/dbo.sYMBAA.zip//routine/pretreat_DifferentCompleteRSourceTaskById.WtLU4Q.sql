CREATE PROCEDURE [dbo].[pretreat_DifferentCompleteRSourceTaskById]
@taskid int,
@status int,
@fileid nvarchar(20)
AS

UPDATE [RSTaskAppendix] SET Account='系统排重整合', UpdateTime=getdate(), FileId=@fileid, UploadTime=getdate() WHERE TaskId=@taskid
UPDATE [RSTask] SET Status=@status WHERE ID=@taskid
go

