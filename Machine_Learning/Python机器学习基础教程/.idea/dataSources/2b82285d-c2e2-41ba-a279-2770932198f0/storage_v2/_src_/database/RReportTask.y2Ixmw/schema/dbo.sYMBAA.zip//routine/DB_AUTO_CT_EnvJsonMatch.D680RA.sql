
--sp_helptext     DB_AUTO_CT_EnvJsonMatch

      
--============================================          
-- TBSTRU CT_EnvJsonMatch             
--============================================          
CREATE PROC [dbo].[DB_AUTO_CT_EnvJsonMatch]          
(           
 @ID1      INT,   --流水号          
 @SiteName	varchar(100),	--网站名称
 @SiteSort	varchar(100),	--目录
 @Title	varchar(100),	--模块标题
 @TableName	varchar(100),	--业务表英文名
 @KeyWord_CN	varchar(50),	--字段中文名
 @KeyWord_JS	varchar(100),	--字段JSON名
 @Parent_JS	varchar(100),	--父JSON
 @FiledValue	varchar(100),	--字段英文名
 @Html_Type	int,	--Html类型
 @Group	varchar(50),	--组别
 @Flag	int,	--是否删除  
 @LoginName  varchar(50) --登陆名                     
 )       
       
 AS          
         
  --获取输入日期与时间                            
 DECLARE @ENTRYDATE DATETIME                            
 SET @ENTRYDATE=CONVERT(VARCHAR(10),GETDATE(),120)                            
 DECLARE @ENTRYTIME VARCHAR(8)                            
 SET @ENTRYTIME=CONVERT(VARCHAR(8),GETDATE(),108)       
 
      
--数据储存开始          
SET XACT_ABORT ON            
BEGIN TRAN FLAG       
 
     
update CT_EnvJsonMatch       
set      
sitename= case when @sitename='-1' then sitename else @sitename end,      
SiteSort=case when @SiteSort='-1' then SiteSort else @SiteSort end,  
Title=case when @Title='-1' then Title else @Title end, 
TableName=case when @TableName='-1' then TableName else @TableName end, 
KeyWord_CN=case when @KeyWord_CN='-1' then KeyWord_CN else @KeyWord_CN end, 
KeyWord_JS=case when @KeyWord_JS='-1' then KeyWord_JS else @KeyWord_JS end, 
Parent_JS=case when @Parent_JS='-1' then Parent_JS else @Parent_JS end, 
FiledValue=case when @FiledValue='-1' then FiledValue else @FiledValue end, 
Html_Type=case when @Html_Type='-999' then Html_Type else @Html_Type end, 
[Group]=case when @Group='-1' then [Group] else @Group end,
Flag=case when @Flag='-999' then Flag else @Flag end
 where id=@id1       
 IF @@ERROR <> 0                                          
  BEGIN                                         
   ROLLBACK TRAN FLAG                                          
   SELECT '更新CT_EnvJsonMatch失败！',0                                         
   RETURN                         
  END        
      
       
 COMMIT TRAN FLAG       
 RETURN @@ERROR 
go

