




--============================================        
-- TBSTRU EnvIAPAMTInfo           
--============================================        
CREATE PROC [dbo].[DB_AUTO_ct_ITPublicIns_rc]        
(         
     @ID1      INT   --流水号        
	,@state	int
	,@LoginName  varchar(50) --登陆名        
 )     
   
 AS   
 
--数据储存开始        
SET XACT_ABORT ON          
BEGIN TRAN FLAG     
    
update ct_ITPublicIns_rc set state=@state where id=@id1     
 IF @@ERROR <> 0                                        
  BEGIN                                       
   ROLLBACK TRAN FLAG                                        
   SELECT '更新ct_ITPublicIns_rc败！',0                                       
   RETURN                       
  END      
    
     
 COMMIT TRAN FLAG     
 RETURN @@ERROR     
go

