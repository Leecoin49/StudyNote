CREATE PROCEDURE [dbo].[dzh_AppendRSourceSameReport]
@id int,
@account nvarchar(50),
@samereport int,
@remark nvarchar(512)
AS

IF EXISTS (SELECT ID FROM [RSDiscardReason] WHERE TaskId=@id)
	BEGIN
	UPDATE [RSDiscardReason] SET Account=@account, SameReportId=@samereport, SameRemark=@remark WHERE TaskId=@id
	END
ELSE
	BEGIN
	INSERT [RSDiscardReason] (TaskId, Account, SameReportId, SameRemark) VALUES (@id, @account, @samereport, @remark)
	END
go

