
CREATE FUNCTION [dbo].[dzh_GetTaskSimilarInfo](@taskid int)
RETURNS varchar(1024)
AS
BEGIN
DECLARE @str varchar(1024)
SET @str = ''
SELECT @str = @str + ',T' + LTRIM(RTRIM(LikeId)) FROM [RSSimilarInfo] WHERE (TaskId=@taskid AND LikeType=1) ORDER BY LikeId
SELECT @str = @str + ',R' + LTRIM(RTRIM(LikeId)) FROM [RSSimilarInfo] WHERE (TaskId=@taskid AND LikeType=3) ORDER BY LikeId
IF LEN(@str)>0
	BEGIN
	SET @str = STUFF(@str, 1, 1, '')
	END
RETURN @str
END
go

