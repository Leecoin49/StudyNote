CREATE PROCEDURE [dbo].[desk_TakeRSourceTaskById]
@account nvarchar(50),
@taskid int,
@result nvarchar(256) output
AS

DECLARE @status1 int
DECLARE @account1 nvarchar(50)
SET @result = 'OK'

SELECT TOP 1 @status1=st.Status, @account1=ta.Account
	FROM [RSTask] st LEFT OUTER JOIN [RSTaskAppendix] ta ON st.Id=ta.TaskId
	WHERE st.ID=@taskid
	ORDER BY st.ID
	
IF @status1 is null
	BEGIN
	SET @result = '指定编号(=' + LTRIM(RTRIM(STR(@taskid))) + ')的研报源任务记录不存在'
	END
ELSE
	BEGIN
	IF (@status1=21 OR @status1=41)
		BEGIN
		IF @account1=@account
			BEGIN
			SET @result = 'OK'
			UPDATE [RSTaskAppendix] SET UpdateTime=getdate() WHERE TaskId=@taskid
			SELECT st.ID, st.RawId, st.CreateTime, st.PublishTime, st.ReportDate, st.TitleRaw, st.TitleShort, st.InstituteName, st.InstituteCode, 
				st.InstituteId, st.Author, st.KindName, st.Kind2Name, st.StkCode, st.StkName, st.Url, st.FileUrl, st.FileUrl_o, st.Status, st.RawName, st.FileStatus, 
				ta.FileName, ta.FileMd5, ta.FileLen, ta.FileId, ta.ReportId, ta.Account, ta.UpdateTime,
				dr.SameReportId, dr.SameRemark,
				dbo.dzh_GetTaskSimilarInfo(st.ID) AS Similar
				FROM [RSTask] st LEFT OUTER JOIN [RSTaskAppendix] ta ON st.Id=ta.TaskId
				LEFT OUTER JOIN [RSDiscardReason] dr ON st.Id=dr.TaskId
				WHERE st.ID=@taskid
				ORDER BY st.ID
			END
		ELSE
			BEGIN
			SET @result = '指定编号(=' + LTRIM(RTRIM(STR(@taskid))) + ')的研报源任务记录已有其他人正在处理'
			END
		END
	ELSE IF @status1=20 OR @status1=40
		BEGIN
		UPDATE [RSTaskAppendix] SET Account=@account, UpdateTime=getdate() WHERE TaskId=@taskid
		IF @status1=20
			BEGIN
			UPDATE [RSTask] SET Status=21 WHERE Id=@taskid
			END
		ELSE
			BEGIN
			UPDATE [RSTask] SET Status=41 WHERE Id=@taskid
			END
		SET @result = 'OK'
		SELECT st.ID, st.RawId, st.CreateTime, st.PublishTime, st.ReportDate, st.TitleRaw, st.TitleShort, st.InstituteName, st.InstituteCode, 
			st.InstituteId, st.Author, st.KindName, st.Kind2Name, st.StkCode, st.StkName, st.Url, st.FileUrl, st.FileUrl_o, st.Status, st.RawName, st.FileStatus, 
			ta.FileName, ta.FileMd5, ta.FileLen, ta.FileId, ta.ReportId, ta.Account, ta.UpdateTime,
			dr.SameReportId, dr.SameRemark,
			dbo.dzh_GetTaskSimilarInfo(st.ID) AS Similar
			FROM [RSTask] st LEFT OUTER JOIN [RSTaskAppendix] ta ON st.Id=ta.TaskId
			LEFT OUTER JOIN [RSDiscardReason] dr ON st.Id=dr.TaskId
			WHERE st.ID=@taskid
			ORDER BY st.ID
		END
	ELSE
		BEGIN
		SET @result = '指定编号(=' + LTRIM(RTRIM(STR(@taskid))) + ')的研报源任务记录已经处理，不能再领取处理'
		END
	END
go

