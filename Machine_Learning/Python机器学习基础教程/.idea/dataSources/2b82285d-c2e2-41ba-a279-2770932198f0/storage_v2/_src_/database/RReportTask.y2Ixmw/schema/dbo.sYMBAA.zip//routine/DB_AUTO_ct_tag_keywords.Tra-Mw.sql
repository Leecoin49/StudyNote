

--============================================          
-- TBSTRU ct_tag_keywords             
--============================================          
CREATE PROC [dbo].[DB_AUTO_ct_tag_keywords]          
(           
 @ID1      INT,   --流水号          
 @key_sname varchar(max),    
 --@EntryDate datetime,    
 @sitesort varchar(300),    
 @combination varchar(500),    
 --@EntryTime varchar(8),    
 @key varchar(500),    
 @tablename varchar(100),    
 @sitename varchar(300),    
 @filedname varchar(100),    
 @url varchar(500),   
 @state int,
 @start_num int, 
 @num_chars int,
 @LoginName  varchar(50) --登陆名          
 )       


 AS          
  
  --获取输入日期与时间                          
 DECLARE @ENTRYDATE DATETIME                          
 SET @ENTRYDATE=CONVERT(VARCHAR(10),GETDATE(),120)                          
 DECLARE @ENTRYTIME VARCHAR(8)                          
 SET @ENTRYTIME=CONVERT(VARCHAR(8),GETDATE(),108)     
    
--数据储存开始          
SET XACT_ABORT ON            
BEGIN TRAN FLAG  

begin    
 update RReportTask..ct_tag_keywords       
 set      
  tablename=@tablename,    
  sitename=@sitename,    
  sitesort=@sitesort,    
  [key]=@key,    
  key_sname=@key_sname,    
  filedname=@filedname,    
  combination=@combination,    
  [url]=@url,   
  [state]=@state,
  start_num=@start_num,
  num_chars=@num_chars,
  EntryDate=CONVERT(varchar(10),getdate(),120),    
  Entrytime=CONVERT(varchar(10),getdate(),108)    
  where id=@id1       
  IF @@ERROR <> 0                                          
   BEGIN                                         
    ROLLBACK TRAN FLAG                                          
    SELECT '更新HtmlMatch失败！',0                                         
    RETURN                         
   END        
  else  
  
if  not exists(select 1 from RReportTask..ct_tag_keywords where tablename=@tablename and sitename=@sitename and sitesort=@sitesort and  [key]=@key and key_sname=@key_sname)    
begin     
 insert into RReportTask..ct_tag_keywords(tablename,sitename,sitesort,[key],key_sname,filedname,combination,state,[url],start_num,num_chars,[EntryDate],[EntryTime])    
 values(@tablename,@sitename,@sitesort,@key,@key_sname,@filedname,@combination,@state,@url,@start_num,@num_chars,@EntryDate,@EntryTime)    		
 IF @@ERROR <> 0                                          
    BEGIN                                         
    ROLLBACK TRAN FLAG                                          
    SELECT '更新失败！',0                                         
    RETURN                         
    END       
end      
end    
    
    
      
       
 COMMIT TRAN FLAG       
 RETURN @@ERROR 
go

