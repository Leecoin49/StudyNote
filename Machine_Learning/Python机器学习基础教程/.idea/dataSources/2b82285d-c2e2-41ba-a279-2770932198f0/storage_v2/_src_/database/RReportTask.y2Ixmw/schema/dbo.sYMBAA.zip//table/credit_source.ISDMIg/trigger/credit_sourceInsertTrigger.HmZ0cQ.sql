create trigger credit_sourceInsertTrigger
on dbo.credit_source
for insert
as 
begin
  begin
  insert into credit_pro(sourceid)
  select inserted.id from inserted ;
  end
end
go

