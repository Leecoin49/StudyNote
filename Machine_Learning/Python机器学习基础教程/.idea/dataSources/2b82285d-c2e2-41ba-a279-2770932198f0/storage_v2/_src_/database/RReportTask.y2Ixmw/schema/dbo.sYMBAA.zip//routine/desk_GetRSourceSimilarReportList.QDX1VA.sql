CREATE PROCEDURE [dbo].[desk_GetRSourceSimilarReportList]
@account nvarchar(50),
@taskid int
AS

SELECT st.ID, st.RawId, st.CreateTime, st.PublishTime, st.TitleRaw, st.TitleShort,  
	st.Url, st.FileUrl, st.FileUrl_o, st.Status, st.InstituteId, st.RawName, st.FileStatus, 
	ta.FileName, ta.FileMd5, ta.FileLen, ta.FileId, ta.Account, ta.UpdateTime,
	0 AS SameReportId, '' AS SameRemark,
	'' AS Similar,
	rrr.ID AS ReportID,
	rrr.PublishDate AS ReportDate,
	rrr.CompanyName as InstituteName,
	rrr.CompanyCode as InstituteCode,
	rrr.TypeCode,
	rrr.TypeName AS KindName,
	'' AS Kind2Name,
	rrr.Symbol AS StkCode,
	rrr.SName as StkName,
	'' as Author,
	rrr.Titles AS rrTitle, 
	'' as rrTitleShort
	FROM [RSSimilarInfo] si
	INNER JOIN RSR_DB.dbo.RSRJudgeInfo rrr ON si.LikeId=rrr.ID
	LEFT OUTER JOIN [RSTaskAppendix] ta ON (ta.ReportId>0 AND rrr.ID=ta.ReportId)	--2013.5.22 zxh 修改，RSTaskAppendix中的ReportId还是保持RSRJudgeInfo表中的ID的值
	LEFT OUTER JOIN [RSTask] st ON ta.TaskId=st.Id
	WHERE si.TaskId=@taskid AND si.LikeType=3
	ORDER BY si.LikeId
go

