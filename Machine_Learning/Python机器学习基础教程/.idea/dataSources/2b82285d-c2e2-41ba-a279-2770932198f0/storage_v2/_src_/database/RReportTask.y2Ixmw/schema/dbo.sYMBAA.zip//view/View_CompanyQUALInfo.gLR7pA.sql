


CREATE VIEW [dbo].[View_CompanyQUALInfo] WITH SCHEMABINDING
AS
SELECT  dbo.CT_Credit_text.id, dbo.CT_CreditSource.grabdatacode, dbo.CT_Credit_text.sourceid, 
                   dbo.CT_CreditSource.datasource, dbo.CT_CreditSource.sitename, dbo.CT_CreditSource.sitesort, 
                   dbo.CT_CreditSource.submodule, dbo.CT_Credit_text.url, dbo.CT_Credit_field.title, dbo.CT_Credit_field.declaredate, 
                   dbo.CT_Credit_text.filepath, dbo.CT_Credit_text.relativepath, dbo.CT_Credit_text.listpath, dbo.CT_Credit_field.inserturl, 
                   dbo.CT_Credit_field.thead, dbo.CT_Credit_text.tablehead, dbo.CT_Credit_text.isfile, dbo.CT_Credit_text.isimg, 
                   dbo.CT_Credit_text.guid, dbo.CT_Credit_text.uniqueguid, dbo.CT_Credit_text.state, dbo.CT_Credit_text.Entrydate, 
                   dbo.CT_Credit_text.Entrytime, dbo.CT_Credit_text.TMStamp, dbo.CT_Credit_text.macip, 
                   dbo.CT_CreditSource.empty_content, dbo.CT_Credit_field.party, dbo.CT_Credit_text.newrelativepath, 
                   dbo.CT_Credit_text.newfilepath, dbo.CT_CreditSource.rawurl, dbo.CT_Credit_text.parentGuid, 
                   dbo.CT_Credit_text.listrelativepath
FROM      dbo.CT_Credit_text INNER JOIN
                   dbo.CT_Credit_field ON dbo.CT_Credit_text.guid = dbo.CT_Credit_field.guid INNER JOIN
                   dbo.CT_CreditSource ON dbo.CT_Credit_text.sourceid = dbo.CT_CreditSource.guid
WHERE   (dbo.CT_CreditSource.modulecode = 303) AND (dbo.CT_CreditSource.submodule = '企业资质')
go

create unique clustered index [ClusteredIndex-20230904-112618]
    on View_CompanyQUALInfo (id)
go

