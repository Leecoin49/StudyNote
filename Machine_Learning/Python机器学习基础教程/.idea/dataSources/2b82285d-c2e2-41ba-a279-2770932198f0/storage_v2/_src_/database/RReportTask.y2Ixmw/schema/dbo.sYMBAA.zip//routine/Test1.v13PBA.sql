CREATE PROCEDURE [dbo].[Test1]  
 (  
 @Age int,   --排名  
 @name  varchar(10)  
 )  
  
AS  
INSERT INTO [t1]([age],[name]) VALUES(@Age,@name)

select * from [t1] where Age=@Age
go

