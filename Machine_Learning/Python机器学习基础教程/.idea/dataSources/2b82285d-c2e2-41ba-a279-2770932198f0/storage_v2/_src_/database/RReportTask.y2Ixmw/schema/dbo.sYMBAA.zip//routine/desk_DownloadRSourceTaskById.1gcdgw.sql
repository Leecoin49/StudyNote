CREATE PROCEDURE [dbo].[desk_DownloadRSourceTaskById]
@account nvarchar(50),
@taskid int,
@upload int,
@filename nvarchar(512),
@result nvarchar(256) output
AS

DECLARE @status1 int
DECLARE @account1 nvarchar(50)
SET @result = 'OK'

SELECT TOP 1 @status1=st.Status, @account1=ta.Account
	FROM [RSTask] st LEFT OUTER JOIN [RSTaskAppendix] ta ON st.Id=ta.TaskId
	WHERE st.ID=@taskid
	ORDER BY st.ID
	
IF @status1 is null
	BEGIN
	SET @result = '指定编号(=' + LTRIM(RTRIM(STR(@taskid))) + ')的研报源任务记录不存在'
	END
ELSE
	BEGIN
	IF (@status1=21 OR @status1=41)
		BEGIN
		IF @account1=@account
			BEGIN
			SET @result = 'OK'
			SET @status1 = @status1 + 1		--22 或 42
			IF @upload<>1
				BEGIN
				SET @status1 = @status1 + 2	--24 或 44
				END
			UPDATE [RSTaskAppendix] SET Account=@account, UpdateTime=getdate(), FileName=@filename WHERE TaskId=@taskid
			UPDATE [RSTask] SET Status=@status1 WHERE ID=@taskid
			
			SELECT st.ID, st.RawId, st.CreateTime, st.PublishTime, st.ReportDate, st.TitleRaw, st.TitleShort, st.InstituteName, st.InstituteCode, 
				st.InstituteId, st.Author, st.KindName, st.Kind2Name, st.StkCode, st.StkName, st.Url, st.FileUrl, st.FileUrl_o, st.Status, st.RawName, st.FileStatus, 
				ta.FileName, ta.FileMd5, ta.FileLen, ta.FileId, ta.ReportId, ta.Account, ta.UpdateTime,
				dr.SameReportId, dr.SameRemark,
				dbo.dzh_GetTaskSimilarInfo(st.ID) AS Similar
				FROM [RSTask] st LEFT OUTER JOIN [RSTaskAppendix] ta ON st.Id=ta.TaskId
				LEFT OUTER JOIN [RSDiscardReason] dr ON st.Id=dr.TaskId
				WHERE st.ID=@taskid
				ORDER BY st.ID
			END
		ELSE
			BEGIN
			SET @result = '指定编号(=' + LTRIM(RTRIM(STR(@taskid))) + ')的研报源任务记录已有其他人正在处理'
			END
		END
	ELSE IF @status1=20 OR @status1=40
		BEGIN
		SET @result = 'OK'
		SET @status1 = @status1 + 2		--22 或 42
		IF @upload<>1
			BEGIN
			SET @status1 = @status1 + 2	--24 或 44
			END
		UPDATE [RSTaskAppendix] SET Account=@account, UpdateTime=getdate(), FileName=@filename WHERE TaskId=@taskid
		UPDATE [RSTask] SET Status=@status1 WHERE ID=@taskid
		SELECT st.ID, st.RawId, st.CreateTime, st.PublishTime, st.ReportDate, st.TitleRaw, st.TitleShort, st.InstituteName, st.InstituteCode, 
			st.InstituteId, st.Author, st.KindName, st.Kind2Name, st.StkCode, st.StkName, st.Url, st.FileUrl, st.FileUrl_o, st.Status, st.RawName, st.FileStatus, 
			ta.FileName, ta.FileMd5, ta.FileLen, ta.FileId, ta.ReportId, ta.Account, ta.UpdateTime,
			dr.SameReportId, dr.SameRemark,
			dbo.dzh_GetTaskSimilarInfo(st.ID) AS Similar
			FROM [RSTask] st LEFT OUTER JOIN [RSTaskAppendix] ta ON st.Id=ta.TaskId
			LEFT OUTER JOIN [RSDiscardReason] dr ON st.Id=dr.TaskId
			WHERE st.ID=@taskid
			ORDER BY st.ID
		END
	ELSE IF @status1=22 OR @status1=42	--2013-01-06 zxh 新增，当已经提交为采集并上传时
		BEGIN
		IF @upload<>1 
			BEGIN
			SET @result = '指定编号(=' + LTRIM(RTRIM(STR(@taskid))) + ')的研报源任务记录已在采集并上传状态，不能重新修改为采集状态'
			END
		ELSE
			BEGIN
			IF @account1=@account
				BEGIN
				SET @result = 'OK'
				--SET @status1 = @status1 + 1		--22 或 42，状态不变
				UPDATE [RSTaskAppendix] SET Account=@account, UpdateTime=getdate(), FileName=@filename WHERE TaskId=@taskid
				UPDATE [RSTask] SET Status=@status1 WHERE ID=@taskid
				
				SELECT st.ID, st.RawId, st.CreateTime, st.PublishTime, st.ReportDate, st.TitleRaw, st.TitleShort, st.InstituteName, st.InstituteCode, 
					st.InstituteId, st.Author, st.KindName, st.Kind2Name, st.StkCode, st.StkName, st.Url, st.FileUrl, st.FileUrl_o, st.Status, st.RawName, st.FileStatus, 
					ta.FileName, ta.FileMd5, ta.FileLen, ta.FileId, ta.ReportId, ta.Account, ta.UpdateTime,
					dr.SameReportId, dr.SameRemark,
					dbo.dzh_GetTaskSimilarInfo(st.ID) AS Similar
					FROM [RSTask] st LEFT OUTER JOIN [RSTaskAppendix] ta ON st.Id=ta.TaskId
					LEFT OUTER JOIN [RSDiscardReason] dr ON st.Id=dr.TaskId
					WHERE st.ID=@taskid
					ORDER BY st.ID
				END
			ELSE
				BEGIN
				SET @result = '指定编号(=' + LTRIM(RTRIM(STR(@taskid))) + ')的研报源任务记录已由其他操作员处理为采集并上传状态'
				END
			END
		END
	ELSE IF @status1=24 OR @status1=44	--2013-01-06 zxh 新增，当已经提交为采集时
		BEGIN
		IF @upload=1 
			BEGIN
			SET @result = '指定编号(=' + LTRIM(RTRIM(STR(@taskid))) + ')的研报源任务记录已在采集状态，不能重新修改为采集并上传状态'
			END
		ELSE
			BEGIN
			IF @account1=@account
				BEGIN
				SET @result = 'OK'
				--SET @status1 = @status1 + 1		--24 或 44，状态不变
				UPDATE [RSTaskAppendix] SET Account=@account, UpdateTime=getdate(), FileName=@filename WHERE TaskId=@taskid
				UPDATE [RSTask] SET Status=@status1 WHERE ID=@taskid
				
				SELECT st.ID, st.RawId, st.CreateTime, st.PublishTime, st.ReportDate, st.TitleRaw, st.TitleShort, st.InstituteName, st.InstituteCode, 
					st.InstituteId, st.Author, st.KindName, st.Kind2Name, st.StkCode, st.StkName, st.Url, st.FileUrl, st.FileUrl_o, st.Status, st.RawName, st.FileStatus, 
					ta.FileName, ta.FileMd5, ta.FileLen, ta.FileId, ta.ReportId, ta.Account, ta.UpdateTime,
					dr.SameReportId, dr.SameRemark,
					dbo.dzh_GetTaskSimilarInfo(st.ID) AS Similar
					FROM [RSTask] st LEFT OUTER JOIN [RSTaskAppendix] ta ON st.Id=ta.TaskId
					LEFT OUTER JOIN [RSDiscardReason] dr ON st.Id=dr.TaskId
					WHERE st.ID=@taskid
					ORDER BY st.ID
				END
			ELSE
				BEGIN
				SET @result = '指定编号(=' + LTRIM(RTRIM(STR(@taskid))) + ')的研报源任务记录已由其他操作员处理为采集状态'
				END
			END
		END
	ELSE
		BEGIN
		SET @result = '指定编号(=' + LTRIM(RTRIM(STR(@taskid))) + ')的研报源任务记录已经处理，不能再领取处理'
		END
	END
go

