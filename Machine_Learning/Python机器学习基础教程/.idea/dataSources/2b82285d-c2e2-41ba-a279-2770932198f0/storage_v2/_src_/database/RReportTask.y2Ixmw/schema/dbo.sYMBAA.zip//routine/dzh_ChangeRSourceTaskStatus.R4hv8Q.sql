CREATE PROCEDURE [dbo].[dzh_ChangeRSourceTaskStatus]
@id int,
@status int,
@account nvarchar(50)
AS

UPDATE [RSTask] SET Status=@status WHERE ID=@id
UPDATE [RSTaskAppendix] SET Account=@account, UpdateTime=GETDATE() WHERE TaskId=@id
go

