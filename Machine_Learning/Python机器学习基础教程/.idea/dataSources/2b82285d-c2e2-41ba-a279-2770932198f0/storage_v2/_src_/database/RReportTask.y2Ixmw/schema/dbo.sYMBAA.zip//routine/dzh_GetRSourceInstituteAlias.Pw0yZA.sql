CREATE PROCEDURE [dbo].[dzh_GetRSourceInstituteAlias]
AS

SELECT InstituteCode, InstituteName FROM [RSR_Ins_AliasName] 
	WHERE (InstituteCode IS NOT NULL) AND InstituteCode<>''
	ORDER BY InstituteCode
go

