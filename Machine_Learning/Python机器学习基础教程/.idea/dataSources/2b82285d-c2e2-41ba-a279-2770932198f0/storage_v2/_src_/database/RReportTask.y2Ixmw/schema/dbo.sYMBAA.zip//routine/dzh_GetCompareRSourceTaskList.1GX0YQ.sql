CREATE PROCEDURE [dbo].[dzh_GetCompareRSourceTaskList]
@id int,
@startdate datetime,
@enddate datetime,
@institutecode varchar(8)
AS

SET @enddate = CONVERT(VARCHAR(10), DATEADD(day, 1, @enddate), 120)
SET @startdate = CONVERT(VARCHAR(10), @startdate, 120)

SELECT st.ID, st.CreateTime, st.ReportDate, st.TitleShort, st.StkCode, st.Status, st.InstituteId, st.InstituteCode, st.KindName
	FROM [RSTask] st 
	WHERE (st.Status<>13 AND st.Status<>14 AND st.Status<>28 AND st.Status<>43 AND st.Status<>48) 
		AND st.InstituteCode=@institutecode AND st.ID<@id 
		AND st.CreateTime>=@startdate AND st.CreateTime<DATEADD(day, 1, @enddate)
		AND (st.Status<>12 OR st.CreateTime>=DATEADD(day, -3, GETDATE()))
	ORDER BY ID
go

