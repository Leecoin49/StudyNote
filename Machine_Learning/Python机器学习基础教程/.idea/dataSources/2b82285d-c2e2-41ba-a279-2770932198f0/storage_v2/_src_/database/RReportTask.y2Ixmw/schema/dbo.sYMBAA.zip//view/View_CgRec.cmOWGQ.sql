CREATE VIEW dbo.View_CgRec
AS
select dbo.CT_Research.id, dbo.CT_Research.sourceid, dbo.CT_ResearchSource.sitename, dbo.CT_ResearchSource.sitesort, dbo.CT_Research.url,   
                   dbo.CT_ResearchField.title, dbo.CT_ResearchField.publishdate, dbo.CT_ResearchSource.grabdatacode, dbo.CT_Research.filepath,   
                   dbo.CT_Research.relativepath, dbo.CT_Research.listpath,dbo.CT_Research.isfile, dbo.CT_Research.isimg,
                    dbo.CT_Research.guid, dbo.CT_Research.uniqueguid, dbo.CT_Research.state, dbo.CT_Research.Entrydate,
                   dbo.CT_Research.Entrytime, dbo.CT_Research.TMStamp, dbo.CT_Research.macip,   
                   dbo.CT_ResearchSource.empty_content, dbo.CT_Research.newrelativepath, dbo.CT_Research.newfilepath,   
                   dbo.CT_ResearchSource.rawurl
FROM         dbo.CT_Research LEFT OUTER JOIN  
                   dbo.CT_ResearchField ON dbo.CT_Research.guid = dbo.CT_ResearchField.guid LEFT OUTER JOIN  
                   dbo.CT_ResearchSource ON dbo.CT_Research.sourceid = dbo.CT_ResearchSource.guid  
WHERE      (dbo.CT_ResearchSource.modulecode = 501)
go

