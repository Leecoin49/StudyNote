CREATE VIEW dbo.view_Research
AS
SELECT   dbo.CT_ResearchSource.sitename, dbo.CT_ResearchSource.KindName, dbo.CT_ResearchSource.RSR_Type_N1, 
                dbo.CT_ResearchSource.modulecode, dbo.CT_ResearchSource.rawurl, dbo.CT_Research.sourceid, 
                dbo.CT_Research.guid, dbo.CT_Research.state, dbo.CT_Research.Entrydate, dbo.CT_Research.Entrytime, 
                dbo.CT_Research.url, dbo.CT_Research.id, dbo.CT_Research.filepath, dbo.CT_Research.relativepath, 
                dbo.CT_Research.listpath, dbo.CT_Research.isfile, dbo.CT_Research.isimg, dbo.CT_Research.uniqueguid, 
                dbo.CT_Research.mainguid, dbo.CT_Research.TMStamp, dbo.CT_Research.macip, dbo.CT_Research.newfilepath, 
                dbo.CT_Research.newrelativepath, dbo.CT_Research.contentpost, dbo.CT_Research.contentheader, 
                dbo.CT_Research.version, dbo.CT_ResearchField.title, dbo.CT_ResearchField.publishdate, 
                dbo.CT_ResearchField.author, dbo.CT_ResearchField.institutename, dbo.CT_ResearchField.stkcode, 
                dbo.CT_ResearchField.stkname, dbo.CT_ResearchField.Kind2Name, dbo.CT_ResearchField.IndGradeName, 
                dbo.CT_ResearchField.StkGradeName, dbo.CT_ResearchField.RSR_Info_N3, dbo.CT_ResearchField.abstract, 
                dbo.CT_ResearchSource.sitesort, dbo.CT_Research.state1, dbo.CT_ResearchSource.grabdatacode
FROM      dbo.CT_Research INNER JOIN
                dbo.CT_ResearchSource ON dbo.CT_Research.sourceid = dbo.CT_ResearchSource.guid INNER JOIN
                dbo.CT_ResearchField ON dbo.CT_Research.guid = dbo.CT_ResearchField.guid
go

exec sp_addextendedproperty 'MS_DiagramPane1', N'[0E232FF0-B466-11cf-A24F-00AA00A3EFFF, 1.00]
Begin DesignProperties = 
   Begin PaneConfigurations = 
      Begin PaneConfiguration = 0
         NumPanes = 4
         Configuration = "(H (1[65] 4[1] 2[17] 3) )"
      End
      Begin PaneConfiguration = 1
         NumPanes = 3
         Configuration = "(H (1 [50] 4 [25] 3))"
      End
      Begin PaneConfiguration = 2
         NumPanes = 3
         Configuration = "(H (1 [50] 2 [25] 3))"
      End
      Begin PaneConfiguration = 3
         NumPanes = 3
         Configuration = "(H (4 [30] 2 [40] 3))"
      End
      Begin PaneConfiguration = 4
         NumPanes = 2
         Configuration = "(H (1 [56] 3))"
      End
      Begin PaneConfiguration = 5
         NumPanes = 2
         Configuration = "(H (2 [66] 3))"
      End
      Begin PaneConfiguration = 6
         NumPanes = 2
         Configuration = "(H (4 [50] 3))"
      End
      Begin PaneConfiguration = 7
         NumPanes = 1
         Configuration = "(V (3))"
      End
      Begin PaneConfiguration = 8
         NumPanes = 3
         Configuration = "(H (1[56] 4[18] 2) )"
      End
      Begin PaneConfiguration = 9
         NumPanes = 2
         Configuration = "(H (1 [75] 4))"
      End
      Begin PaneConfiguration = 10
         NumPanes = 2
         Configuration = "(H (1[66] 2) )"
      End
      Begin PaneConfiguration = 11
         NumPanes = 2
         Configuration = "(H (4 [60] 2))"
      End
      Begin PaneConfiguration = 12
         NumPanes = 1
         Configuration = "(H (1) )"
      End
      Begin PaneConfiguration = 13
         NumPanes = 1
         Configuration = "(V (4))"
      End
      Begin PaneConfiguration = 14
         NumPanes = 1
         Configuration = "(V (2))"
      End
      ActivePaneConfig = 0
   End
   Begin DiagramPane = 
      Begin Origin = 
         Top = 0
         Left = 0
      End
      Begin Tables = 
         Begin Table = "CT_Research"
            Begin Extent = 
               Top = 6
               Left = 38
               Bottom = 452
               Right = 218
            End
            DisplayFlags = 280
            TopColumn = 2
         End
         Begin Table = "CT_ResearchSource"
            Begin Extent = 
               Top = 14
               Left = 507
               Bottom = 352
               Right = 1070
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "CT_ResearchField"
            Begin Extent = 
               Top = 251
               Left = 380
               Bottom = 495
               Right = 601
            End
            DisplayFlags = 280
            TopColumn = 7
         End
      End
   End
   Begin SQLPane = 
   End
   Begin DataPane = 
      Begin ParameterDefaults = ""
      End
   End
   Begin CriteriaPane = 
      Begin ColumnWidths = 11
         Column = 1440
         Alias = 900
         Table = 1170
         Output = 720
         Append = 1400
         NewValue = 1170
         SortType = 1350
         SortOrder = 1410
         GroupBy = 1350
         Filter = 1350
         Or = 1350
         Or = 1350
         Or = 1350
      End
   End
End
', 'SCHEMA', 'dbo', 'VIEW', 'view_Research'
go

exec sp_addextendedproperty 'MS_DiagramPaneCount', 1, 'SCHEMA', 'dbo', 'VIEW', 'view_Research'
go

