CREATE PROCEDURE [dbo].[dzh_ChangeRSourceTaskCompleteInfo]
@id int,
@status int,
@reportid int,
@account nvarchar(50)
AS

UPDATE [RSTask] SET Status=@status WHERE ID=@id
UPDATE [RSTaskAppendix] SET UpdateTime=GETDATE(), ReportId=@reportid WHERE TaskId=@id
go

