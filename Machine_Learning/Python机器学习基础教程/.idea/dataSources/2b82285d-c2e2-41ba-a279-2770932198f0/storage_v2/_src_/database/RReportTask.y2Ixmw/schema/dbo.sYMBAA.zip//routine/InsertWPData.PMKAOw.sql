-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[InsertWPData] 
	-- Add the parameters for the stored procedure here
	@url nvarchar(200),@indicname nvarchar(200),@region nvarchar(200), 
    @classify varchar(50), @indic nvarchar(200), @entrydate datetime, 
    @pubdate1 varchar(50),@pubdate2 varchar(50),@pubdate3 varchar(50),@pubdate4 varchar(50),@pubdate5 varchar(50),
    @data1 varchar(200),@data2 varchar(200),@data3 varchar(200),@data4 varchar(200),@data5 varchar(200)
AS
BEGIN
  if(@pubdate1<>'' and @data1 <> '' and @region<>'')
  begin
	  if not Exists (select * from IndustryRawData where Indic= @indic and Classify= @classify and Region= Replace(@region,' ','') and 
	  PubDate = @pubdate1 and Data = replace(@data1,' ',''))
	  begin
	  INSERT INTO IndustryRawData (SOURCE_URL,SOURCE_TITLE,Region,EntryDate,Classify,Indic,PubDate,Data) VALUES 
	  (@url,Replace(@indicname,' ',''),Replace(@region,' ',''), @entrydate,@classify,@indic,@pubdate1,replace(@data1,' ',''))
	  end
  end
  if(@pubdate2<>'' and @data2 <> '' and @region<>'')
  begin
  	  if not Exists (select * from IndustryRawData where Indic= @indic and Classify= @classify and Region= Replace(@region,' ','') and 
	  PubDate = @pubdate2 and Data = replace(@data2,' ',''))
	  begin
		INSERT INTO IndustryRawData (SOURCE_URL,SOURCE_TITLE,Region,EntryDate,Classify,Indic,PubDate,Data) VALUES 
	  (@url,Replace(@indicname,' ',''),Replace(@region,' ',''), @entrydate,@classify,@indic,@pubdate2,replace(@data2,' ',''))
	  end
  end
  if(@pubdate3<>'' and @data3 <> '' and @region<>'')
  begin
  	  if not Exists (select * from IndustryRawData where Indic= @indic and Classify= @classify and Region= Replace(@region,' ','') and 
	  PubDate = @pubdate3 and Data = replace(@data3,' ',''))
	  begin
		INSERT INTO IndustryRawData (SOURCE_URL,SOURCE_TITLE,Region,EntryDate,Classify,Indic,PubDate,Data) VALUES 
	  (@url,Replace(@indicname,' ',''),Replace(@region,' ',''), @entrydate,@classify,@indic,@pubdate3,replace(@data3,' ',''))
	  end
  end
  if(@pubdate4<>'' and @data4 <> '' and @region<>'')
  begin
  	  if not Exists (select * from IndustryRawData where Indic= @indic and Classify= @classify and Region= Replace(@region,' ','') and 
	  PubDate = @pubdate4 and Data = replace(@data4,' ',''))
	  begin
		INSERT INTO IndustryRawData (SOURCE_URL,SOURCE_TITLE,Region,EntryDate,Classify,Indic,PubDate,Data) VALUES 
	  (@url,Replace(@indicname,' ',''),Replace(@region,' ',''), @entrydate,@classify,@indic,@pubdate4,replace(@data4,' ',''))
	  end
  end
  if(@pubdate5<>'' and @data5 <> '' and @region<>'')
  begin
  	  if not Exists (select * from IndustryRawData where Indic= @indic and Classify= @classify and Region= Replace(@region,' ','') and 
	  PubDate = @pubdate5 and Data = replace(@data5,' ',''))
	  begin
		INSERT INTO IndustryRawData (SOURCE_URL,SOURCE_TITLE,Region,EntryDate,Classify,Indic,PubDate,Data) VALUES 
	  (@url,Replace(@indicname,' ',''),Replace(@region,' ',''), @entrydate,@classify,@indic,@pubdate5,replace(@data5,' ',''))
	  end
  end
END


go

