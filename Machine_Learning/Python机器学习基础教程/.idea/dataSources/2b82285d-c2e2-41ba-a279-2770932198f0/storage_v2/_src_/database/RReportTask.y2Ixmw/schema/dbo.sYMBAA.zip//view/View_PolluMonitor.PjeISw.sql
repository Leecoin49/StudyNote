CREATE VIEW dbo.View_PolluMonitor
AS
SELECT  TOP (100) PERCENT dbo.CT_EnvPro_Text.id, dbo.CT_CreditSource.sitename, dbo.CT_CreditSource.net_path, 
                   dbo.CT_CreditSource.submodule, dbo.CT_CreditSource.sitesort, dbo.CT_CreditSource.grabdatacode, 
                   dbo.CT_EnvPro_Text.sourceid, dbo.CT_CreditSource.datasource, dbo.CT_EnvPro_Text.modulename, 
                   dbo.CT_EnvPro_Text.url, dbo.CT_EnvPro_Text.contentpost, dbo.CT_EnvPro_Field.dataid, dbo.CT_EnvPro_Field.party, 
                   dbo.CT_EnvPro_Field.title, dbo.CT_EnvPro_Field.year, dbo.CT_EnvPro_Field.url_id, dbo.CT_EnvPro_Field.max_url_id, 
                   dbo.CT_EnvPro_Field.declaredate, dbo.CT_EnvPro_Text.version, dbo.CT_EnvPro_Field.release, 
                   dbo.CT_EnvPro_Field.status, dbo.CT_EnvPro_Text.filepath, dbo.CT_EnvPro_Text.relativepath, 
                   dbo.CT_EnvPro_Text.listpath, dbo.CT_EnvPro_Text.listrelativepath, dbo.CT_EnvPro_Text.part_filepath, 
                   dbo.CT_EnvPro_Text.guid, dbo.CT_EnvPro_Text.parentguid, dbo.CT_EnvPro_Text.[level], dbo.CT_EnvPro_Text.state, 
                   dbo.CT_EnvPro_Field.inserturl, dbo.CT_EnvPro_Text.isimg, dbo.CT_EnvPro_Text.isfile, dbo.CT_EnvPro_Text.entrydate, 
                   dbo.CT_EnvPro_Text.entrytime, dbo.CT_EnvPro_Text.tmstamp, dbo.CT_EnvPro_Text.mainguid
FROM      dbo.CT_CreditSource INNER JOIN
                   dbo.CT_EnvPro_Text ON dbo.CT_CreditSource.guid = dbo.CT_EnvPro_Text.sourceid INNER JOIN
                   dbo.CT_EnvPro_Field ON dbo.CT_EnvPro_Text.guid = dbo.CT_EnvPro_Field.guid
WHERE   (dbo.CT_CreditSource.modulecode = 305) AND (dbo.CT_CreditSource.submodule IN ('污染源监测', '自行监测', 
                   '监督性监测', '监督监测'))
go

exec sp_addextendedproperty 'MS_DiagramPane1', N'[0E232FF0-B466-11cf-A24F-00AA00A3EFFF, 1.00]
Begin DesignProperties = 
   Begin PaneConfigurations = 
      Begin PaneConfiguration = 0
         NumPanes = 4
         Configuration = "(H (1[44] 4[41] 2[15] 3) )"
      End
      Begin PaneConfiguration = 1
         NumPanes = 3
         Configuration = "(H (1 [50] 4 [25] 3))"
      End
      Begin PaneConfiguration = 2
         NumPanes = 3
         Configuration = "(H (1 [50] 2 [25] 3))"
      End
      Begin PaneConfiguration = 3
         NumPanes = 3
         Configuration = "(H (4 [30] 2 [40] 3))"
      End
      Begin PaneConfiguration = 4
         NumPanes = 2
         Configuration = "(H (1 [56] 3))"
      End
      Begin PaneConfiguration = 5
         NumPanes = 2
         Configuration = "(H (2 [66] 3))"
      End
      Begin PaneConfiguration = 6
         NumPanes = 2
         Configuration = "(H (4 [50] 3))"
      End
      Begin PaneConfiguration = 7
         NumPanes = 1
         Configuration = "(V (3))"
      End
      Begin PaneConfiguration = 8
         NumPanes = 3
         Configuration = "(H (1[56] 4[18] 2) )"
      End
      Begin PaneConfiguration = 9
         NumPanes = 2
         Configuration = "(H (1 [75] 4))"
      End
      Begin PaneConfiguration = 10
         NumPanes = 2
         Configuration = "(H (1[66] 2) )"
      End
      Begin PaneConfiguration = 11
         NumPanes = 2
         Configuration = "(H (4 [60] 2))"
      End
      Begin PaneConfiguration = 12
         NumPanes = 1
         Configuration = "(H (1) )"
      End
      Begin PaneConfiguration = 13
         NumPanes = 1
         Configuration = "(V (4))"
      End
      Begin PaneConfiguration = 14
         NumPanes = 1
         Configuration = "(V (2))"
      End
      ActivePaneConfig = 0
   End
   Begin DiagramPane = 
      Begin Origin = 
         Top = 0
         Left = -99
      End
      Begin Tables = 
         Begin Table = "CT_CreditSource"
            Begin Extent = 
               Top = 76
               Left = 443
               Bottom = 534
               Right = 1006
            End
            DisplayFlags = 280
            TopColumn = 36
         End
         Begin Table = "CT_EnvPro_Text"
            Begin Extent = 
               Top = 152
               Left = 1348
               Bottom = 666
               Right = 1895
            End
            DisplayFlags = 280
            TopColumn = 14
         End
         Begin Table = "CT_EnvPro_Field"
            Begin Extent = 
               Top = 154
               Left = 2138
               Bottom = 606
               Right = 2669
            End
            DisplayFlags = 280
            TopColumn = 0
         End
      End
   End
   Begin SQLPane = 
   End
   Begin DataPane = 
      Begin ParameterDefaults = ""
      End
   End
   Begin CriteriaPane = 
      Begin ColumnWidths = 11
         Column = 4308
         Alias = 900
         Table = 3852
         Output = 720
         Append = 1400
         NewValue = 1170
         SortType = 1356
         SortOrder = 1416
         GroupBy = 1350
         Filter = 2688
         Or = 1350
         Or = 1350
         Or = 1350
      End
   End
End
', 'SCHEMA', 'dbo', 'VIEW', 'View_PolluMonitor'
go

exec sp_addextendedproperty 'MS_DiagramPaneCount', 1, 'SCHEMA', 'dbo', 'VIEW', 'View_PolluMonitor'
go

