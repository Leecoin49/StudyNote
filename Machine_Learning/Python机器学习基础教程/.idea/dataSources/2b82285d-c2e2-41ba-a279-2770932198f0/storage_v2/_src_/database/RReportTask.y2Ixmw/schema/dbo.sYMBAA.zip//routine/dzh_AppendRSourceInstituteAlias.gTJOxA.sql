CREATE PROCEDURE [dbo].[dzh_AppendRSourceInstituteAlias]
@code nvarchar(8),
@name nvarchar(50),
@clearany int
AS

IF @clearany=1
	BEGIN
	DELETE [RSR_Ins_AliasName] WHERE (InstituteCode IS NOT NULL) AND (InstituteCode<>'')
	END
	
INSERT [RSR_Ins_AliasName] (InstituteName, InstituteCode) VALUES (@name, @code)
go

