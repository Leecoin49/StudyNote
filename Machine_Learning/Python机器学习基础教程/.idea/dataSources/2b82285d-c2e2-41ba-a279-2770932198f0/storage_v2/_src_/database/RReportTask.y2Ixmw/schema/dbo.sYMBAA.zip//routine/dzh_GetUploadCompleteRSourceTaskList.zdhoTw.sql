CREATE PROCEDURE [dbo].[dzh_GetUploadCompleteRSourceTaskList]
@topnum int
AS

IF @topnum<=0
	BEGIN
	SET @topnum = 1000000
	END

SELECT TOP(@topnum) st.ID, st.Status, ta.FileId, ta.ReportId, ta.Account, ta.UpdateTime, ta.UploadTime
	FROM [RSTask] st LEFT OUTER JOIN [RSTaskAppendix] ta ON st.Id=ta.TaskId
	WHERE st.Status=27 OR st.Status=47
	--UpdateTime小于等于当前时间-60秒，也就是说，上次更新时间早于当前时间60秒
	--ORDER BY st.ID DESC
	ORDER BY ta.UpdateTime, st.ID DESC
go

