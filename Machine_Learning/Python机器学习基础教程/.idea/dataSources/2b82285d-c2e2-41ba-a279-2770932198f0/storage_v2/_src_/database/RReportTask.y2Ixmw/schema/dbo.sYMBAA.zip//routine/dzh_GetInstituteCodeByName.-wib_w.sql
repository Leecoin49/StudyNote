CREATE PROCEDURE [dbo].[dzh_GetInstituteCodeByName]
@institutename nvarchar(80),
@institutecode nvarchar(8) output
AS

IF (@institutename is null)
	BEGIN
	SET @institutecode = ''
	END
ELSE
	BEGIN
	SET @institutename = LTRIM(RTRIM(@institutename))
	IF @institutename=''
		BEGIN
		SET @institutecode = ''
		END
	ELSE
		BEGIN
		SELECT TOP 1 @institutecode=CompanyCode FROM [RSR_Ins_Corr] WHERE RSR_Ins_Corr1=@institutename OR RSR_Ins_Corr2=@institutename OR RSR_Ins_Corr3=@institutename ORDER BY CompanyCode
		IF (@institutecode is null)
			BEGIN
			SET @institutecode = ''
			END
		END
	END
go

