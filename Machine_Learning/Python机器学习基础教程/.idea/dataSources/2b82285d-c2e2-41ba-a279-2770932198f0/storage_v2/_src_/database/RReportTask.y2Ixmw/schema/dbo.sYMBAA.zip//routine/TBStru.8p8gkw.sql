
CREATE PROCEDURE [dbo].[TBStru] (                
 @TABLENAME VARCHAR(50)                
) AS                
-- ===================================                
-- 传入表设计名，显示字段列表及表名                
-- [TBStru] MI_INDEX                
-- AUTH:JM                
-- DATE:2009-12-25                
-- ===================================                
SELECT                 
[中文名] = D.CNAME,[设计名] = A.[NAME]                
--,[类型] = B.[NAME],[长度] = A.LENGTH,[精度级别] = A.prec,[小数位数] = A.scale                
,[类型] = B.[NAME]                
   +CASE WHEN B.[NAME] IN ('numeric','decimal') THEN '('+CAST(A.prec AS VARCHAR)+','+CAST(A.scale AS VARCHAR)+')'                
    WHEN B.[NAME] IN ('NVARCHAR','nchar') THEN '('+CAST(A.prec AS VARCHAR)+')'                 
    WHEN B.[NAME] IN ('VARCHAR','char') THEN '('+CAST(A.LENGTH AS VARCHAR) +')'                
    ELSE '' END                 
,[单位] = ISNULL(D.UnitS,'')                
,[数据字典值] = CASE USEDATADICT WHEN 1 THEN 'SELECT * FROM FCDB_HF..DATADICT_COLUMNVALUE WHERE CID = ' + CAST (D.ID AS VARCHAR) ELSE '' END                  
,[字段说明] = ISNULL(D.Meaning,'')                  
,[表中文名] = C.[CNAME]                
,[业务主键] = ISNULL(C.KEYWORDS,'')                
FROM SYSCOLUMNS                 
 A LEFT JOIN                
SYSTYPES B ON A.XTYPE = B.XTYPE LEFT JOIN                
(SELECT * FROM DATADICT_OBJECTS WHERE NAME=@TABLENAME)C       
ON OBJECT_ID(C.[NAME]) = A.ID    
LEFT JOIN DATADICT_COLUMNS D       
ON C.ID = D.OID AND A.[NAME] = D.[NAME]                 
WHERE A.ID = OBJECT_ID(@TABLENAME) AND B.[NAME]<>'SYSNAME'--AND B.STATUS<>1                 
ORDER BY CAST(ISNULL(D.COLUMNINDEX,'9999') AS INT)                
--ORDER BY CAST(ISNULL(D.COLUMNINDEX,A.COLORDER) AS INT) 
go

