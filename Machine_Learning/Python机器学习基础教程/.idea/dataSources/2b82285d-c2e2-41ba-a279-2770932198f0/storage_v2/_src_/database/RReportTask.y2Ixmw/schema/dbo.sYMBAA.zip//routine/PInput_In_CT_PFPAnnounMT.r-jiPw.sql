CREATE PROCEDURE [dbo].[PInput_In_CT_PFPAnnounMT]
(                 
 @Sitename varchar(200),  --网站          
 @Sitesort1 varchar(200),  --目录          
 @Url  varchar(1000),    --链接          
 @Title   varchar(500), --标题          
 @Declaredate  varchar(100),    --日期                
 @Content  text,    --内容          
 @Systemno varchar(20),   --编码          
 @Downfilelist varchar(500),	--附件链接
 @Downfilename varchar(500),	--附件名称
 @Downfileurl varchar(2000)	--附件目录
) AS

 --获取输入日期与时间              
 DECLARE @ENTRYDATE DATETIME              
 SET @ENTRYDATE=CONVERT(VARCHAR(10),GETDATE(),120)              
 DECLARE @ENTRYTIME VARCHAR(8)              
 SET @ENTRYTIME=CONVERT(VARCHAR(8),GETDATE(),108)          
 
   --数据储存开始          
 SET XACT_ABORT ON          
 BEGIN TRAN FLAG    
 
 DECLARE @GUID uniqueidentifier
 set @GUID = newid()
 
 IF @Downfileurl = ''
 BEGIN 
	 INSERT INTO [CT_PFPAnnounMT] ([SITENAME],[SITESORT1],[URL],[TITLE],[DECLAREDATE],[STATE],[UNIQUECODE],[Content],[SYSTEMNO]) 
	 VALUES (@Sitename,@Sitesort1,@Url,@Title,@Declaredate,0,@GUID,@Content,@Systemno) 
 END

 IF @Downfileurl != ''
 BEGIN
	 INSERT INTO [CT_PFPAnnounMT_file] ([DOWNFILELIST],[DOWNFILENAME],[STATE],[UNIQUECODE],[DOWNFILEURL]) 
	 VALUES (@Downfilelist,@Downfilename,0,@GUID,@Downfileurl)
	 
	 DECLARE @TEMP INT
	 SET @TEMP = (select count(1) from CT_PFPAnnounMT where UNIQUECODE=@GUID)
	 IF @TEMP>0
	 BEGIN 
		 INSERT INTO [CT_PFPAnnounMT] ([SITENAME],[SITESORT1],[URL],[TITLE],[DECLAREDATE],[STATE],[UNIQUECODE],[Content],[SYSTEMNO]) 
		 VALUES (@Sitename,@Sitesort1,@Url,@Title,@Declaredate,0,@GUID,@Content,@Systemno) 
	 END
 END
 


 COMMIT TRAN FLAG                
 RETURN 0 
 
go

