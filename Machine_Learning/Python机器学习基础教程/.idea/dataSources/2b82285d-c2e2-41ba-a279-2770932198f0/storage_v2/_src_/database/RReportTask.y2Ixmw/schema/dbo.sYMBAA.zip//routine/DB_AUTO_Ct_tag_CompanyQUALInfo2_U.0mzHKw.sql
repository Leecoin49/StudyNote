



  
            
-- =================================================          
       
-- is_proc_input_tb Ct_tag_CompanyQUALInfo2,2        
-- DATE: 2023/8/4
-- =================================================                          
                          
CREATE PROCEDURE [dbo].[DB_AUTO_Ct_tag_CompanyQUALInfo2_U]                          
(    @ID1 INT, --流水号      
     @Sitename	varchar(200),	--网站
     @Sitesort	varchar(200),	--目录
     @Key	varchar(500),        --代码
     @Key_sname	varchar(500),	 --代码对应值
     @Combination	varchar(500),--拼接值
     @State	int,				 --状态
     @Url	varchar(500),		 --网址
     @Contains	varchar(200),	 --包含
     @Nocontains	varchar(200),--不得包含
     @TableAt	varchar(20),	 --所在表格
     @LoginName  varchar(50)                        
) AS                       
            
 --获取存储日期时间                          
 DECLARE @ENTRYDATE VARCHAR(10)                          
 DECLARE @ENTRYTIME VARCHAR(8)                          
 SET @ENTRYDATE=CONVERT(VARCHAR(10),GETDATE(),120)                          
 SET @ENTRYTIME=CONVERT(VARCHAR(8),GETDATE(),108)                          
                           
 DECLARE @OPERNeedFile VARCHAR(1)                          
                              
                
 --数据储存开始                          
 SET XACT_ABORT ON                            
 BEGIN TRAN FLAG                          
                          
    UPDATE Ct_tag_CompanyQUALInfo2                   
    SET        
    Sitename =CASE WHEN @Sitename='-1' THEN Sitename ELSE @Sitename END,       
    Sitesort =CASE WHEN @Sitesort='-1' THEN Sitesort ELSE @Sitesort END,                       
    [Key] =CASE WHEN @Key='-1' THEN [Key] ELSE @Key END,       
    Key_sname =CASE WHEN @Key_sname='-1' THEN Key_sname ELSE @Key_sname END,       
    Combination =CASE WHEN @Combination='-1' THEN Combination ELSE @Combination END,         
    state =CASE WHEN @state='-1' THEN state ELSE @state END,      
    Url =CASE WHEN @Url='-1' THEN Url ELSE @Url END,  
	[Contains] =CASE WHEN @Contains='-1' THEN [Contains] ELSE @Contains END,  
	Nocontains =CASE WHEN @Nocontains='-1' THEN Nocontains ELSE @Nocontains END,  
	TableAt =CASE WHEN @TableAt='-1' THEN TableAt ELSE @TableAt END,  
    ENTRYDATE=@ENTRYDATE,                      
    ENTRYTIME=@ENTRYTIME                       
    WHERE ID=@ID1                       
    IF @@ERROR <> 0                       
  BEGIN                      
   ROLLBACK TRAN FLAG                       
   SELECT 'Ct_tag_CompanyQUALInfo2更新失败,请联系管理员！',0                      
   RETURN                       
  END                       
                      
   SET @OPERNeedFile='U'                      
                           
 ------记录Inputlog信息                      
 --IF @OPERNeedFile='U'                      
 --BEGIN                       
 -- INSERT INTO InputLog(TBName,TBKeys,UpTime,OperNeedFile,OperUser,ToolName,[Status])                      
 -- VALUES('Ct_tag_CompanyQUALInfo2',CAST(@ID1 AS VARCHAR),GETDATE(),@OPERNeedFile,@LoginName,'DB_AUTO',1)                      
 -- IF @@ERROR <> 0                       
 -- BEGIN                      
 --  ROLLBACK TRAN FLAG                       
 --  SELECT 'Inputlog表中新增记录失败，请联系管理员！',@ID1                      
 --  RETURN                       
 -- END                       
 --END           
             
 SELECT ''                      
 COMMIT TRAN FLAG                        
 RETURN 0   
go

