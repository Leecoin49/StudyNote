 
CREATE function [dbo].[LN_ComParPRO]
(@tbname varchar(100))
returns @TempTable table (sqlstr  varchar(max))
as
begin
with s1 as (
select @tbname as tbname,b.name,b.colorder
from sysobjects a inner join syscolumns b
on a.id=b.id
where a.name =@tbname AND b.name<>'ModifyTimeStamp'
),
s2 as 
(select MAX(colorder) as colorder from s1
),
s3 AS
(
select a.TABLE_NAME,b.COLUMN_NAME
from information_schema.table_constraints a 
inner join information_schema.constraint_column_usage b 
on a.constraint_name = b.constraint_name 
where a.constraint_type = 'PRIMARY KEY' and a.table_name =@tbname
)
insert into @TempTable(sqlstr)
select '/***********************************************************'
UNION ALL
SELECT '此函数用语对比数据更新--李楠'
UNION ALL
SELECT '***********************************************************/'
union all
select 
'MERGE INTO '+@tbname+' as T '
UNION ALL
SELECT 'USING ('
union all
select 'SELECT * FROM CYBPMCOST.CYBPMCOSTDB1041.dbo.'+@tbname
union all
SELECT ') as S'
union all
select  'ON (T.'+NAME+'='+'S.'+name+')' FROM V0PKeyColumns WHERE TableName=''+@tbname+''
union all
select 'WHEN MATCHED THEN '
union all
select 'UPDATE SET'
union all
select 'T.'+name+'='+'S.'+name+',' from s1 where colorder<>(select colorder from s2) AND NAME<>(SELECT COLUMN_NAME FROM s3)--AND name NOT IN (SELECT name FROM V0PKeyColumns WHERE TableName=''+@tbname+'')
union all
select 'T.'+name+'='+'S.'+name from s1 where colorder=(select colorder from s2) AND NAME<>(SELECT COLUMN_NAME FROM s3)--AND name NOT IN (SELECT name FROM V0PKeyColumns WHERE TableName=''+@tbname+'')
union all
select 'WHEN NOT MATCHED THEN '
union all
select 'INSERT'
union all
select '('
union all
select name +',' from s1 where colorder<>(select colorder from s2)
union all
select name from s1 where colorder=(select colorder from s2)
union all
select ')'
union all
SELECT 'VALUES'
UNION ALL
SELECT '('
union all
select 'S.'+name +','from s1 where colorder<>(select colorder from s2)
union all
select'S.'+name from s1 where colorder=(select colorder from s2)
union all                             
select '); '
return
end
go

