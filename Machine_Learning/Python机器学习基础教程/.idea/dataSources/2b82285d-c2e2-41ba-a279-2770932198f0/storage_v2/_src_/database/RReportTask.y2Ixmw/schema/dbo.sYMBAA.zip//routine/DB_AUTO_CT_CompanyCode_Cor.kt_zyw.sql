


--EXEC [DB_AUTO_CT_CompanyCode_Cor] '10000001',12,'121212',1,'ZHAOMY'


CREATE PROC [dbo].[DB_AUTO_CT_CompanyCode_Cor]      
(
	@CompanyCode	varchar(8) --机构代码	
	,@CType	int				   --对应类型	
	,@OutCode	varchar(20)	   --外部代码	
	,@Status	int				   --状态
    ,@LoginName Varchar(50)      
)      
AS      
 DECLARE @OPERTYPE VARCHAR(1)      
 SET ANSI_WARNINGS OFF      
       
 --获取输入日期与时间      
 DECLARE @ENTRYDATE DATETIME      
 SET @ENTRYDATE=CONVERT(VARCHAR(10),GETDATE(),120)      
 DECLARE @ENTRYTIME VARCHAR(8)      
 SET @ENTRYTIME=CONVERT(VARCHAR(8),GETDATE(),108)      
 
 --数据储存开始      
 SET XACT_ABORT ON        
 BEGIN TRAN FLAG   

 IF @CType=12 AND @Status=1
 BEGIN 		
		DECLARE @COMPANYNAME	varchar(200)
		SET @COMPANYNAME=(SELECT TOP 1 COMPANYNAME from [10.17.107.166].FCDB_HF.DBO.ITPROFILE  
		WHERE CompanyCode=@CompanyCode )

		INSERT INTO ct_CompanyCode_Cor([CompanyCode],[CType],[OutCode],[state],[EntryDate],[EntryTime]) 
		VALUES(@CompanyCode,@CType,@OutCode,0,@EntryDate,@EntryTime)
		IF @@ERROR<>0
		BEGIN
		     ROLLBACK TRAN FLAG
		     RAISERROR('新增记录错误',16,1)
		     RETURN @@ERROR
		END
 END 
       
 COMMIT TRAN FLAG
 RETURN @@ERROR
go

