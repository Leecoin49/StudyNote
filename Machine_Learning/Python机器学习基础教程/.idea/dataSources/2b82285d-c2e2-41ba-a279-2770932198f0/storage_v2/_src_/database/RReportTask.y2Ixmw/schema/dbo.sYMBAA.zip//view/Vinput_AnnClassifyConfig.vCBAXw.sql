

CREATE VIEW [dbo].[View_AnnClassifyConfig]
AS
select id 流水号,AnnType 数据来源,BusinessType 业务类型,BusinessTypeDetails 业务类型明细,[Group] 分组,FieldName 字段名,												
       [Contains] 包含的关键字,NoContains 不包含的关键字,DocConvertFun 转换功能,DatabaseName 入库表名,QueueName 解析队列名,case when Flag=0 then '有效' else '失效' end 是否有效 												
from  rreporttask..AnnClassifyConfig 												

go

