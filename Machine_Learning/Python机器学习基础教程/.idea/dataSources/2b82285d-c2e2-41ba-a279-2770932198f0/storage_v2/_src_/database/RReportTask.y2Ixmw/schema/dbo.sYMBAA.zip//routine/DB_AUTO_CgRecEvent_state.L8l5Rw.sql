  
--============================================      
-- 违规信用事件中间表（内部使用）自动导入      
-- TBSTRU CgRecEvent_DataMid    is_proc_input_tb CgRecEvent_DataMid,2      
-- TBSTRU CgRecEvent_party         
--============================================      
CREATE PROC [dbo].[DB_AUTO_CgRecEvent_state]      
(       
 @ID1      INT,   --流水号      
 @TABLENAME VARCHAR(100), --来源表名      
 @state  CHAR(2),   --从表是否审核      
 @LoginName  varchar(50) --登陆名      
 ) AS      
  
  
DECLARE @ENTRYDATE VARCHAR(10)      
DECLARE @ENTRYTIME VARCHAR(8)      
SET @ENTRYDATE=CONVERT(VARCHAR(10),GETDATE(),120)      
SET @ENTRYTIME=CONVERT(VARCHAR(8),GETDATE(),108)      
  
DECLARE @OPERTYPE VARCHAR(1)      
SET @OPERTYPE='U'  
  
if isnull(@TABLENAME,'')='' OR @TABLENAME NOT IN ('ct_CgRecEvent_DataMid','ct_CgRecEvent_DataMid_new','ct_CgRecEvent_DataMid_new1','ct_CgRecEvent_DataMid1','ct_PSupportInfo_List','CT_AfficheBaseInfo','CT_CgRecEvent_Creditlist','CT_CgRecEvent_cxbzd')  
begin  
 RAISERROR ('来源表取值有误！',16,1)  
 RETURN @@ERROR   
end  
  
--数据储存开始      
SET XACT_ABORT ON        
BEGIN TRAN FLAG   
  
DECLARE @SQL1 VARCHAR(500)  
--SET @SQL1='UPDATE '+@TABLENAME+' SET State='''+@state+''',ENTRYDATE='''+@ENTRYDATE+''',ENTRYTIME='''+@ENTRYTIME+''' where ID='+CAST(@ID1 AS VARCHAR(20))  
SET @SQL1='UPDATE '+@TABLENAME+' SET State='''+@state+''' where ID='+CAST(@ID1 AS VARCHAR(20))  

  
--print @sql1  
exec (@SQL1)  
  
   
 COMMIT TRAN FLAG   
 RETURN @@ERROR
go

