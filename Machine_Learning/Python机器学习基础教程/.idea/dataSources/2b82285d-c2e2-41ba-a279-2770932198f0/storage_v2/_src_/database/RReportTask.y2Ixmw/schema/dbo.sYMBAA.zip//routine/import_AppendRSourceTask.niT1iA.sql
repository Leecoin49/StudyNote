CREATE PROCEDURE [dbo].[import_AppendRSourceTask]
@rawid int,
@rawname nvarchar(20),
@createtime datetime,
@publishtime datetime,
@reportdate datetime,
@titleraw nvarchar(256),
@titleshort nvarchar(256),
@institutename nvarchar(80),
@institutecode varchar(8),
@author nvarchar(50),
@kindname nvarchar(50),
@kind2name nvarchar(50),
@stkcode nvarchar(20),
@stkname nvarchar(50),
@url nvarchar(1000),
@fileurl nvarchar(1000),
@fileurl_o nvarchar(1000),
@status int,

@filename nvarchar(255),
@filemd5 nvarchar(50),
@filelen int,
@filestatus int,

@taskid int output
AS

SELECT TOP 1 @taskid=ID FROM [RSTask] WHERE RawId=@rawid AND RawName=@rawname
IF @taskid is null
	BEGIN
	IF (@institutecode IS NULL) OR @institutecode=''
		BEGIN
		DECLARE @institutecode1 varchar(8)
		SELECT TOP 1 @institutecode1=InstituteCode FROM [RSR_Ins_AliasName] WHERE InstituteName=@institutename AND (InstituteCode IS NOT NULL) AND InstituteCode<>''
		IF (@institutecode1 is not null) AND @institutecode1<>''
			BEGIN
			SET @institutecode = LTRIM(RTRIM(@institutecode1))
			END
		END
		
	INSERT [RSTask] (RawId, CreateTime, PublishTime, ReportDate, TitleRaw, TitleShort, InstituteName, InstituteId, Author, KindName, Kind2Name, StkCode, StkName, Url, FileUrl, FileUrl_o, Status, InstituteCode, RawName, FileStatus)
		VALUES (@rawid, @createtime, @publishtime, @reportdate, @titleraw, @titleshort, @institutename, 0, @author, @kindname, @kind2name, @stkcode, @stkname, @url, @fileurl, @fileurl_o, @status, @institutecode, @rawname, @filestatus)
		
	SELECT TOP 1 @taskid=ID FROM [RSTask] WHERE RawId=@rawid AND RawName=@rawname
	END

IF NOT EXISTS (SELECT * FROM [RSTaskAppendix] WHERE TaskId=@taskid)
	BEGIN
	INSERT [RSTaskAppendix] (TaskId, FileName, FileMd5, FileLen, FileId, ReportId, Account, UpdateTime)
		VALUES (@taskid, @filename, @filemd5, @filelen, '', 0, '系统导入新增', getdate())
	END
go

