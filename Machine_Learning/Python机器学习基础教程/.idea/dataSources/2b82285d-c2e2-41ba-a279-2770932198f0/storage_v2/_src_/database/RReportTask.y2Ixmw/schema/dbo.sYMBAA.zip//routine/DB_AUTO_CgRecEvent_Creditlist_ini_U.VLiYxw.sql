


  
            
-- =================================================          
       
-- is_proc_input_tb CgRecEvent_Creditlist_ini,2        
-- DATE: 2022/8/17
-- =================================================                          
                          
CREATE PROCEDURE [dbo].[DB_AUTO_CgRecEvent_Creditlist_ini_U]                          
(    @ID1 INT, --流水号      
     @Sitename	varchar(200),	--网站
     @Sitesort	varchar(200),	--目录
     @Sitesort1	varchar(500),	--详细目录路径
     @Url	varchar(500),	--网址
     @CgRecEvent_BCRType1	varchar(200),	--名单类型
     @CgRecEvent_BCRAnn1	varchar(500),	--标题
     @CgRecEvent_BCRAnn6	varchar(500),	--处理人
     @CgRecEvent_BCRAnn7	varchar(500),	--标准发文单位
     @Htmlmatch_flag	varchar(50) ,	--标识
     @Type	varchar(50) 	,--类型
     @Tag_flag	varchar(50) 	,--标题对应
     @Taskname	varchar(200),	--需求任务名
     @Username	varchar(200),	--需求提交者
     @Pyusername	varchar(200),	--系管配置者
     @Taskmemo	varchar(200),	--配置状态
     @TitleReplace	varchar(1000),	--标题替换
     @DeclareDate	varchar(50) ,	--公告日期
     @Memo	varchar(500),	--备注
     @Area	varchar(100),	--地区
     @ListReplace	varchar(1000),	--特殊替换
     @ListFilter	varchar(1000),	--特殊过滤
   @LoginName  varchar(50)                        
) AS                       
            
 --获取存储日期时间                          
 DECLARE @ENTRYDATE VARCHAR(10)                          
 DECLARE @ENTRYTIME VARCHAR(8)                          
 SET @ENTRYDATE=CONVERT(VARCHAR(10),GETDATE(),120)                          
 SET @ENTRYTIME=CONVERT(VARCHAR(8),GETDATE(),108)                          
                           
 DECLARE @OPERTYPE VARCHAR(1)                          
                              
                
 --数据储存开始                          
 SET XACT_ABORT ON                            
 BEGIN TRAN FLAG                          
                          
    UPDATE CgRecEvent_Creditlist_ini                   
    SET        
    Sitename =CASE WHEN @Sitename='-1' THEN Sitename ELSE @Sitename END,       
    Sitesort =CASE WHEN @Sitesort='-1' THEN Sitesort ELSE @Sitesort END,                       
    Sitesort1 =CASE WHEN @Sitesort1='-1' THEN Sitesort1 ELSE @Sitesort1 END,       
    Url =CASE WHEN @Url='-1' THEN Url ELSE @Url END,       
    CgRecEvent_BCRType1 =CASE WHEN @CgRecEvent_BCRType1='-1' THEN CgRecEvent_BCRType1 ELSE @CgRecEvent_BCRType1 END,         
    CgRecEvent_BCRAnn1 =CASE WHEN @CgRecEvent_BCRAnn1='-1' THEN CgRecEvent_BCRAnn1 ELSE @CgRecEvent_BCRAnn1 END,         
    CgRecEvent_BCRAnn6 =CASE WHEN @CgRecEvent_BCRAnn6='-1' THEN CgRecEvent_BCRAnn6 ELSE @CgRecEvent_BCRAnn6 END,   
    CgRecEvent_BCRAnn7 =CASE WHEN @CgRecEvent_BCRAnn7='-1' THEN CgRecEvent_BCRAnn7 ELSE @CgRecEvent_BCRAnn7 END, 
    Htmlmatch_flag =CASE WHEN @Htmlmatch_flag='-1' THEN Htmlmatch_flag ELSE @Htmlmatch_flag END, 
    Type =CASE WHEN @Type='-999' THEN Type ELSE @Type END,      
    Tag_flag =CASE WHEN @Tag_flag='-1' THEN Tag_flag ELSE @Tag_flag END,         
    Taskname =CASE WHEN @Taskname='-1' THEN Taskname ELSE @Taskname END,                       
    Username=CASE WHEN @Username='-1' THEN Username ELSE @Username END,
    Pyusername =CASE WHEN @Pyusername='-1' THEN Pyusername ELSE @Pyusername END,      
    Taskmemo =CASE WHEN @Taskmemo='-999' THEN Taskmemo ELSE @Taskmemo END,  
    TitleReplace =CASE WHEN @TitleReplace='-1' THEN TitleReplace ELSE @TitleReplace END,  
    DeclareDate =CASE WHEN @DeclareDate='0000-00-00' THEN DeclareDate ELSE @DeclareDate END,  
    Memo =CASE WHEN @Memo='-1' THEN Memo ELSE @Memo END,  
    Area =CASE WHEN @Area='-1' THEN Area ELSE @Area END,  
    ListReplace =CASE WHEN @ListReplace='-1' THEN ListReplace ELSE @ListReplace END,  
    ListFilter =CASE WHEN @ListFilter='-1' THEN ListFilter ELSE @ListFilter END,  
    ENTRYDATE=@ENTRYDATE,                      
    ENTRYTIME=@ENTRYTIME                       
    WHERE ID=@ID1                       
    IF @@ERROR <> 0                       
  BEGIN                      
   ROLLBACK TRAN FLAG                       
   SELECT 'CgRecEvent_Creditlist_ini更新失败,请联系管理员！',0                      
   RETURN                       
  END                       
                      
   SET @OPERTYPE='U'                      
                           
 ------记录Inputlog信息                      
 --IF @OPERTYPE='U'                      
 --BEGIN                       
 -- INSERT INTO InputLog(TBName,TBKeys,UpTime,OperType,OperUser,ToolName,[Status])                      
 -- VALUES('CgRecEvent_Creditlist_ini',CAST(@ID1 AS VARCHAR),GETDATE(),@OPERTYPE,@LoginName,'DB_AUTO',1)                      
 -- IF @@ERROR <> 0                       
 -- BEGIN                      
 --  ROLLBACK TRAN FLAG                       
 --  SELECT 'Inputlog表中新增记录失败，请联系管理员！',@ID1                      
 --  RETURN                       
 -- END                       
 --END           
             
 SELECT ''                      
 COMMIT TRAN FLAG                        
 RETURN 0   
go

