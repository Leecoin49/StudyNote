CREATE TRIGGER UpdateSecondTable
ON CT_Credit_text
AFTER UPDATE
AS
BEGIN
	UPDATE RreportTask..CT_Credit_field
	SET guid = 'F9421DAB-A33C-4E7B-9C95-C2F04B2C6BBB'
	FROM RreportTask..CT_Credit_field AS CT_Credit_field
	INNER JOIN RreportTask..CT_Credit_text AS CT_Credit_text
	ON CT_Credit_text.guid = CT_Credit_field.guid
	WHERE CT_Credit_text.sourceid = '3016684727592858'
	AND CT_Credit_field.title = '祝朝霞26.95千瓦光伏电站'
	AND CT_Credit_field.declaredate = '2023-08-13 00:00:00.000';
END;
go

