


-- =================================================          
-- TBSTRU EnvJsonMatch       
-- is_proc_input_tb EnvJsonMatch,2        
-- DATE: 2023/8/14
-- =================================================
CREATE PROCEDURE [dbo].[DB_AUTO_EnvJsonMatch] 
(   
	@ID1 INT --流水号      
	,@SiteName			varchar(200)	--网站名称
	,@SiteSort			varchar(100)	--目录
	,@title				varchar(200)	--模块标题
	,@TableName			varchar(200)	--业务表设计名
	,@KeyWord_CN			varchar(200)	--字段中文名
	,@KeyWord_JS			varchar(200)	--字段JSON名
	,@Parent_JS			varchar(200)	--父JSON
	,@FiledValue			varchar(200)	--字段英文名
	,@Html_Type			int					--Html类型
	,@MDataSourceCode	varchar(200)	--监控数据源代码(内部使用)
	,@Group				varchar(200)			--组别
	,@isModel			int						--是否模型抽取
	,@JSONValue			varchar(5000)		--JSON值
	,@MatchValue			varchar(5000)		--JSON映射值
	,@EnvJsonMatch1		varchar(500)	--备用字段1
	,@EnvJsonMatch2		varchar(1000)	--备用字段2
	,@Flag				int	--是否删除
	,@LoginName  varchar(50)                        
) AS                       
            
 --获取存储日期时间                          
 DECLARE @ENTRYDATE VARCHAR(10)                          
 DECLARE @ENTRYTIME VARCHAR(8)                          
 SET @ENTRYDATE=CONVERT(VARCHAR(10),GETDATE(),120)                          
 SET @ENTRYTIME=CONVERT(VARCHAR(8),GETDATE(),108)                          
                           
 DECLARE @OPERNeedFile VARCHAR(1)                          
                              
                
 --数据储存开始                          
 SET XACT_ABORT ON                            
 BEGIN TRAN FLAG                          

	IF ISNULL(@ID1,0)>0
	BEGIN
	    DECLARE @SQL VARCHAR(8000)
		SET @SQL='
		update EnvJsonMatch         
		Set ' 
		IF @Sitename!='-1' SET @SQL= @SQL+'Sitename='''+@Sitename +''','	+CHAR(10)
		IF @Sitesort!='-1' SET @SQL= @SQL+'Sitesort='''+@Sitesort +''','	+CHAR(10)
		IF @Title!='-1' SET @SQL= @SQL+'Title='''+@Title +''','	+CHAR(10)
		IF @TableName!='-1' SET @SQL= @SQL+'TableName='''+@TableName +''','	+CHAR(10)
		IF @Parent_JS!='-1' SET @SQL= @SQL+'Parent_JS='''+@Parent_JS +''','	+CHAR(10)	
		IF @MDATASOURCECODE!='-1' SET @SQL= @SQL+'MDATASOURCECODE='''+@MDATASOURCECODE +''','	+CHAR(10)
		IF @FiledValue!='-1' SET @SQL= @SQL+'FiledValue='''+@FiledValue +''','	+CHAR(10)	
		IF @Html_Type!='-1' SET @SQL= @SQL+'Html_Type='''+Cast(@Html_Type as varchar) +''','	+CHAR(10)	
		IF @KeyWord_CN!='-1' SET @SQL= @SQL+'KeyWord_CN='''+@KeyWord_CN +''','	+CHAR(10)	
		IF @KeyWord_JS!='-1' SET @SQL= @SQL+'KeyWord_JS='''+@KeyWord_JS +''','	+CHAR(10)
		IF @Group!='-1' SET @SQL= @SQL+'[Group]='''+@Group +''','	+CHAR(10)	
		IF @isModel!='-1' SET @SQL= @SQL+'isModel='''+Cast(@isModel as varchar)+''','+CHAR(10)
		IF @JSONValue!='-1' SET @SQL= @SQL+'JSONValue='''+@JSONValue+''','	+CHAR(10)
		IF @MatchValue!='-1' SET @SQL= @SQL+'MatchValue='''+@MatchValue+''','+CHAR(10)
		IF @EnvJsonMatch1!='-1' SET @SQL= @SQL+'EnvJsonMatch1='''+@EnvJsonMatch1+''','+CHAR(10)	
		IF @EnvJsonMatch2!='-1' SET @SQL= @SQL+'EnvJsonMatch2='''+@EnvJsonMatch2+''','+CHAR(10)	
		IF @Flag!='-1' SET @SQL= @SQL+'Flag='''+Cast(@Flag as varchar)+''','+CHAR(10)	
		IF isnull(@Parent_JS,'')='' SET @SQL= @SQL+'Parent_JS	   =	'''','+CHAR(10)
		IF isnull(@JSONValue,'')='' SET @SQL= @SQL+'JSONValue= NULL,'+CHAR(10)
		IF isnull(@MatchValue,'')='' SET @SQL= @SQL+'MatchValue= NULL,'+CHAR(10)
		IF isnull(@EnvJsonMatch1,'')='' SET @SQL= @SQL+'EnvJsonMatch1= NULL,'+CHAR(10)
		IF isnull(@EnvJsonMatch2,'')='' SET @SQL= @SQL+'EnvJsonMatch2= NULL,'+CHAR(10)

		SET @SQL=@SQL+'
		EntryDate=CONVERT(varchar(10),getdate(),120),
		EntryTime=CONVERT(varchar(10),getdate(),108) 
		where id='+Cast(@ID1 as varchar)+' '
		--PRINT(@SQL)
		EXEC(@SQL)
                      
	   SET @OPERNeedFile='U'                      
   END 
   ELSE 
   BEGIN
	  INSERT INTO EnvJsonMatch(
			 SiteName
			,SiteSort			
			,title				
			,TableName			
			,KeyWord_CN		
			,KeyWord_JS		
			,Parent_JS			
			,FiledValue		
			,Html_Type			
			,MDataSourceCode	
			,[Group]				
			,isModel			
			,JSONValue			
			,MatchValue		
			,EnvJsonMatch1		
			,EnvJsonMatch2		
			,Flag)
	  VALUES(@SiteName
			,@SiteSort			
			,@title				
			,@TableName			
			,@KeyWord_CN		
			,@KeyWord_JS
			,@Parent_JS--case when isnull(@Parent_JS,'')='' then'' else @Parent_JS	end				
			,@FiledValue		
			,@Html_Type			
			,@MDataSourceCode	
			,@Group				
			,@isModel			
			,@JSONValue			
			,@MatchValue		
			,@EnvJsonMatch1		
			,@EnvJsonMatch2		
			,@Flag)

			SET @OPERNeedFile='A'	
   END
   
 SELECT ''                      
 COMMIT TRAN FLAG                        
 RETURN 0   

go

