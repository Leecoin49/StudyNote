-- dbo.View_EnvFriendly_File source

CREATE VIEW [dbo].[View_EnvFriendly_File]
AS
SELECT  dbo.CT_Credit_file.id, dbo.CT_CreditSource.grabdatacode, dbo.CT_CreditSource.sitename, dbo.CT_CreditSource.sitesort, dbo.CT_Credit_text.sourceid, dbo.CT_Credit_file.url, dbo.CT_Credit_file.pathdate, dbo.CT_Credit_file.guid, 
          dbo.CT_Credit_file.parentguid, dbo.CT_Credit_file.filepath, dbo.CT_Credit_file.relativepath, dbo.CT_Credit_file.state, dbo.CT_Credit_file.macip, dbo.CT_Credit_file.Entrytime, dbo.CT_Credit_file.Entrydate, dbo.CT_Credit_file.TMStamp, 
          dbo.CT_Credit_file.filename, dbo.CT_Credit_file.run_num
FROM    dbo.CT_Credit_file INNER JOIN
          dbo.CT_Credit_text ON dbo.CT_Credit_file.parentguid = dbo.CT_Credit_text.guid INNER JOIN
          dbo.CT_CreditSource ON dbo.CT_Credit_text.sourceid = dbo.CT_CreditSource.guid
WHERE  (dbo.CT_Credit_file.modulecode = 305);
go

