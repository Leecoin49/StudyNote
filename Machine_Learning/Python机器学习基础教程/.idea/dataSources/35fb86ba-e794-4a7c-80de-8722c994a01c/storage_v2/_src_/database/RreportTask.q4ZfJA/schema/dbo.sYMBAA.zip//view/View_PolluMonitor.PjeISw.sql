

CREATE VIEW [dbo].[View_PolluMonitor] WITH SCHEMABINDING
AS
SELECT  dbo.CT_EnvPro_Text.id, dbo.CT_CreditSource.sitename, dbo.CT_CreditSource.net_path, dbo.CT_CreditSource.submodule, dbo.CT_CreditSource.sitesort,   
          dbo.CT_CreditSource.grabdatacode, dbo.CT_EnvPro_Text.sourceid, dbo.CT_CreditSource.datasource, dbo.CT_EnvPro_Text.modulename, dbo.CT_EnvPro_Text.url, dbo.CT_EnvPro_Text.contentpost,   
          dbo.CT_EnvPro_Field.dataid, dbo.CT_EnvPro_Field.party, dbo.CT_EnvPro_Field.title, dbo.CT_EnvPro_Field.year,dbo.CT_EnvPro_Field.url_id,dbo.CT_EnvPro_Field.max_url_id, dbo.CT_EnvPro_Field.declaredate, dbo.CT_EnvPro_Text.version,   
          dbo.CT_EnvPro_Field.release, dbo.CT_EnvPro_Field.status, dbo.CT_EnvPro_Text.filepath, dbo.CT_EnvPro_Text.relativepath, dbo.CT_EnvPro_Text.listpath, dbo.CT_EnvPro_Text.listrelativepath,   
          dbo.CT_EnvPro_Text.part_filepath, dbo.CT_EnvPro_Text.guid, dbo.CT_EnvPro_Text.parentguid, dbo.CT_EnvPro_Text.[level], dbo.CT_EnvPro_Text.state, dbo.CT_EnvPro_Field.inserturl,   
          dbo.CT_EnvPro_Text.isimg, dbo.CT_EnvPro_Text.isfile, dbo.CT_EnvPro_Text.entrydate, dbo.CT_EnvPro_Text.entrytime, dbo.CT_EnvPro_Text.tmstamp, dbo.CT_EnvPro_Text.mainguid  
FROM   dbo.CT_CreditSource INNER JOIN  
          dbo.CT_EnvPro_Text ON dbo.CT_CreditSource.guid = dbo.CT_EnvPro_Text.sourceid INNER JOIN  
          dbo.CT_EnvPro_Field ON dbo.CT_EnvPro_Text.guid = dbo.CT_EnvPro_Field.guid  
WHERE (dbo.CT_CreditSource.modulecode = 305) AND (dbo.CT_CreditSource.submodule = '污染源监测')  
go

create unique clustered index idx_View_PolluMonitor_id
    on View_PolluMonitor (id)
go

create index idx_View_PolluMonitor_sourceId_modulename_state_tmStamp
    on View_PolluMonitor (sourceid, modulename, state, tmstamp)
go

create index idx_View_PolluMonitor_tmStamp
    on View_PolluMonitor (tmstamp, sourceid, modulename, state)
go

